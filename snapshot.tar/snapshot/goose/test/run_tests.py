#!/usr/bin/env python3
"""Goose test runner: parses every test file, checks dump/reparse/dump
roundtrips to identical output, typechecks files not marked `parse-only` on
their first line, checks that error tests fail in the right phase, and (when a
C compiler is available) compiles and runs the generated C at -O0 and -O2,
comparing the two runs and required output in expected/<name>.out.
expected/<name>.aborts marks tests whose run is expected to end in a runtime
abort (nonzero exit) after printing their expected stdout. Each nonblank line
in expected/<name>.stderr must occur in stderr, so an unrelated crash cannot
satisfy an expected abort. Compiler error fixtures require `// error:`
diagnostic substrings in their source and the compiler's normal error exit.
`// warning:` substrings declare the warnings a fixture's typecheck prints,
one warning line each, in any order; a positive fixture without them must
print none. A first-line `runtime-debug` marker adds a targeted
GS_DEBUG=1 run, alongside the existing codegen_exec debug coverage.
A first-line `dump-runtime` marker also executes the parser's dump, checking
that stable roundtripping preserved the original program's behavior.

A compiler built with the TinyCC backend runs the same programs a second way,
in JIT mode: no C file and no external compiler, the generated C built and run
inside the compiler process. Those runs are compared with the same blessed
outputs. A first-line `no-jit` marker leaves a test out of them, and a program
the backend refuses outright is counted as a skip, not a failure.

The language reference's examples (docs/reference.md) are checked by
scripts/check_doc_examples.py, a process of its own like the samples' runner:
every code block of the document compiles, the blocks marked `// error` fail,
and where the JIT runs, each complete program's output is the one the
document shows after it.

The audio/ tests use the SDL3 PCM mixer without a device, the gfx/ tests
use the SDL3 graphics module, the physics/ tests the Box3D
physics module and the ui/ tests the Nuklear ui module. They always parse,
typecheck and generate C; they build and run where the compiler has the
native layers they use built in -- their category's, and any other they
import, as a ui test drawing through gfx does -- built by `goose build`,
which links the packages the compiler was configured with, and a machine
without a GPU device counts as a skip for gfx. A fixture there with
`// error:` markers is a rejection test, as in errors_tc/. The packages
check their modules against their C layers themselves (test/api_check.py in
each of their repositories).

Profiles keep the CI coverage deliberate: baseline compares Goose/native C
-O0 and -O2 plus the targeted debug-runtime runs; sanitize uses Goose -O2 and
Clang -O1 with ASan/UBSan on Linux, including the samples and C runtime tests.
The goose_in_goose/ compiler is one multi-file bootstrap fixture: build three
native generations, require identical stage-2/stage-3 C, and run a self-check
of the stage-2 compiler, which stands for both, beside stage 3's build.
TinyCC also emits the same C when available.

The work runs on --jobs threads, each waiting on the processes it starts, and
the log comes out in the same order whatever the number of jobs: each piece of
work prints into a buffer of its own, shown once everything before it has
been. The log is in sections, each ending in a line counting its checks, with
everything but the ok lines printed in place: failures with what led to them,
and skips. -v prints the ok lines too; under GitHub Actions they are in a
collapsed group per section. The FAIL lines repeat at the end, with their
sections. A fixture's own runs happen one after another, since a program may
write files the next run of it would see. The bootstrap's chains at each level, its
JIT self-compiles and the samples' runner start first, being the longest.
One compiler run per fixture parses, checks the dump roundtrip (--roundtrip)
and typechecks; one per level writes the C and also runs the program through
TinyCC (-o with --jit). -j1 runs everything in order on one thread.

The checking runs go --batch files to one compiler process (goose
--multi-test), and the C of --batch fixtures builds into one executable that
runs any of their programs (CC.compile_programs), each run still a process of
its own; a batch that crashes or does not build leaves its files to runs of
their own, which report the failure as theirs. --batch 1 runs everything one
to a process.

  python test/run_tests.py [--exe path/to/goose] [--nocgen] [--no-jit] [-j N] [--batch N] [-v]
"""

import argparse
import ctypes
import json
import concurrent.futures
import os
import platform
import re
import shutil
import subprocess
import sys
import threading
import time
import traceback
from contextlib import contextmanager
from pathlib import Path

HERE = Path(__file__).resolve().parent
sys.path.insert(0, str(HERE.parent / "scripts"))
import toolchain as tc


def native_modules(f, native):
    """The native modules a fixture uses: its category directory's, and any
    other it imports itself."""
    mods = [f.parent.name] if f.parent.name in native else []
    for m in tc.native_imports(f.read_text(encoding="utf-8")):
        if m not in mods:
            mods.append(m)
    return mods


def joined(text):
    """Output as it is compared: LF endings (run_capture already folded them)
    and no trailing blank line, which is how the blessed files are stored."""
    return text.rstrip("\n")


def first_line(path):
    with open(path, encoding="utf-8", errors="replace") as f:
        return f.readline()


def debug_fixture(f, line):
    """Whether a fixture also runs with GS_DEBUG: codegen_exec.goose and
    those whose first line asks for it."""
    return f.stem == "codegen_exec" or "runtime-debug" in line


def fixture_levels(levels, line):
    """Selected optimizer regressions exercise O1 as well as the profile levels."""
    return tuple(sorted(set(levels) | {"1"})) if "all-levels" in line else levels


def has_bce_annotations(f):
    return bool(re.search(r"//\s*bce:(?:elide|keep)\b", f.read_text(encoding="utf-8")))


def front_args(line, bce):
    """The flags of a positive fixture's one parse, roundtrip and typecheck
    run, by its first line and whether it has bce annotations."""
    # The bce annotations describe -O1.
    return ["--roundtrip"] + (["--parse"] if "parse-only" in line else
                              ["--check"] + (["-O1", "--bce-test"] if bce else []))


def runtime_defines(source):
    """The -D a fixture's first line asks every compile of it for."""
    source = Path(source)
    if source.suffix != ".goose" or not source.is_file():
        return []
    return re.findall(r"^// runtime-define: (\w+=\w+)$", first_line(source))


# What `goose --multi-test` ends each file's part of stdout and of stderr
# with, on a line of its own, followed by the file's exit code and name.
MULTIMARK = "==== goose --multi-test: exit"


def split_multi(text, files):
    """A `goose --multi-test` stream cut at each file's mark: (exit code,
    what the file printed) for each file it has the mark of, in order, and
    what follows the last mark. The line break before a mark is the mark's
    own."""
    parts, pos = [], 0
    for f in files:
        m = re.compile(rf"\n{re.escape(MULTIMARK)} (-?\d+) {re.escape(str(f))}\n").search(text, pos)
        if not m:
            break
        parts.append((int(m[1]), text[pos:m.start()]))
        pos = m.end()
    return parts, text[pos:]


def error_markers(path):
    return re.findall(r"^// error: (.+)$", path.read_text(encoding="utf-8"), re.MULTILINE)


def warning_markers(path):
    return re.findall(r"^// warning: (.+)$", path.read_text(encoding="utf-8"), re.MULTILINE)


def unmatched_warnings(markers, warnings):
    """Pairs each marker with a warning line of its own whose message contains
    it, as many as can be paired, and returns the markers and the lines left
    over. `warnings` holds (line, message) pairs. A marker can be part of
    several messages, so taking the first line that fits could leave another
    marker without the only line it fits: this is a maximum bipartite
    matching (augmenting paths). A line repeating an earlier one is offered
    last, so that it is the one left over when a warning prints twice."""
    lines = [line for line, _ in warnings]
    order = sorted(range(len(lines)), key=lambda w: lines[w] in lines[:w])
    owner = [None] * len(lines)

    def place(m, tried):
        for w in order:
            if w not in tried and markers[m] in warnings[w][1]:
                tried.add(w)
                if owner[w] is None or place(owner[w], tried):
                    owner[w] = m
                    return True
        return False

    missing = [marker for m, marker in enumerate(markers) if not place(m, set())]
    extra = [line for w, line in enumerate(lines) if owner[w] is None]
    return missing, extra


def call_chain(depth, nest=0):
    """A program whose compile-time call path is `depth` calls long: distinct
    functions, each calling the next from inside `nest` blocks."""
    fns = []
    for i in range(depth):
        call = f"step{i + 1}(a[0], n - 1) + 1"
        for _ in range(nest):
            call = f"{{ {call} }}"
        fns.append(f"fn step{i}(x: i64, n: i64) -> i64 {{\n"
                   f"    if n == 0 {{ return 0; }}\n"
                   f"    let a: i64[1] = [x];\n"
                   f"    {call}\n"
                   f"}}\n")
    fns.append(f"fn step{depth}(x: i64, n: i64) -> i64 {{ n }}\n")
    fns.append("fn main() { print(step0(1, 3)); }\n")
    return "".join(fns)


def guard_runs(guards, links):
    """A program of `guards` guards in a row, in a function's body and in a
    loop's, and of a chain of `links` single-use functions, each calling the
    next behind four guards. It prints `guards - 1`, -1, 5 and 3."""
    lines = ["fn many(x: i64) -> i64 {"]
    lines += [f"    guard x != {i} else {{ return {i}; }}" for i in range(guards)]
    lines += ["    -1", "}",
              "fn skips(n: i64) -> i64 {", "    var hits = 0;", "    for x in n {"]
    lines += [f"        guard x != {i} else {{ continue; }}" for i in range(guards)]
    lines += ["        hits++;", "    }", "    hits", "}"]
    for i in range(links):
        lines += [f"fn link{i}(x: i64, n: i64) -> i64 {{",
                  "    guard n != 0 else { return 0; }",
                  "    guard x != -1 else { return -1; }",
                  "    guard x != -2 else { return -2; }",
                  "    guard x != -3 else { return -3; }",
                  "    let a: i64[1] = [x];",
                  f"    link{i + 1}(a[0], n - 1) + 1",
                  "}"]
    lines.append(f"fn link{links}(x: i64, n: i64) -> i64 {{ n }}")
    lines.append(f'fn main() {{ print(many({guards - 1}), " ", many(-1), " ", '
                 f'skips({guards + 5}), " ", link0(1, 3)); }}')
    return "\n".join(lines) + "\n"


class Out:
    """What one piece of the suite printed and how many failures it counted,
    held until the pieces before it have printed theirs. `value` is what the
    piece hands on to a later one."""

    def __init__(self):
        self.text = []
        self.failures = 0
        self.value = None


class Section:
    """One section of the log, printed as its slots finish: what they print
    but their ok lines, in place, and a closing line counting its checks.
    ok lines print too with `verbose`. Under GitHub Actions they go into
    collapsed groups, closed before anything else prints, so that no failure
    hides inside one. Without either, the title starts the line that the
    counts end, unless something else prints in between. Either way the
    title prints as the section starts, ahead of anything in it, and shows
    where the suite was should it stop there."""

    def __init__(self, title, verbose, github):
        self.title, self.verbose, self.github = title, verbose, github
        self.oks, self.fails, self.failures = 0, [], 0
        # "title": the title is on a line not yet ended; "group": a GitHub
        # group is open; None: at the start of a line, outside a group.
        if github:
            sys.stdout.write(f"::group::{title}\n")
            self.state = "group"
        else:
            sys.stdout.write(f"== {title}" + ("\n" if verbose else ""))
            self.state = None if verbose else "title"
        sys.stdout.flush()

    def add(self, out):
        self.failures += out.failures
        for line in "".join(out.text).splitlines():
            if line.startswith("ok   "):
                self.oks += 1
                if self.github:
                    if self.state != "group":
                        sys.stdout.write(f"::group::{self.title} (continued)\n")
                        self.state = "group"
                elif not self.verbose:
                    continue
            else:
                if line.startswith("FAIL "):
                    self.fails.append(line)
                sys.stdout.write({"group": "::endgroup::\n", "title": "\n"}.get(self.state, ""))
                self.state = None
            sys.stdout.write(line + "\n")
        sys.stdout.flush()

    def close(self):
        # A failure that printed no FAIL line still counts.
        fails = max(len(self.fails), self.failures)
        counts = f"{self.oks} ok" + (f", {fails} FAIL" if fails else "")
        if self.state == "title":
            sys.stdout.write(f": {counts}\n")
        else:
            sys.stdout.write(("::endgroup::\n" if self.state == "group" else "") +
                             f"== {self.title}: {counts}\n")
        sys.stdout.flush()


class Fixture:
    """One positive fixture's results, an Out per section of the log it
    prints in, and the skips it adds to the summaries."""

    def __init__(self):
        self.front, self.bce, self.cgen, self.dump = Out(), Out(), Out(), Out()
        self.debug, self.jit, self.jitdebug = Out(), Out(), Out()
        self.nativeskips, self.jitskips = [], []
        # What fixture() found and generated, for the rest of the fixture.
        self.line, self.dumped = "", False
        # By build_options key, the compiler run that wrote the C and where.
        self.modules, self.jitlevels, self.gen, self.c = [], (), {}, {}
        # Whether the compiler builds its program (goose build) rather than
        # this runner: a .build sidecar beside it (C of its own), or a
        # packages/ fixture, whose packages may have C the runner cannot
        # see.
        self.sidecar = False


class Runner:
    """Runs the suite's work on a pool of threads, which mostly wait for the
    processes they start, and prints it in a fixed order: each piece of work
    prints into an Out of its own, and `sections` lists, in the order the log
    shows them, each section's title and its slots, the callables that hand
    the Outs over. A job may wait for a job submitted before it, which the
    pool has started by then, never for a later one. With one job everything
    runs as it is submitted, on this thread."""

    def __init__(self, exe, jobs, verbose=False):
        self.exe = exe
        self.failures = 0
        # Every FAIL line the log printed, with its section's title.
        self.failed = []
        self.verbose = verbose
        self.github = os.environ.get("GITHUB_ACTIONS") == "true"
        self.local = threading.local()
        self.pool = concurrent.futures.ThreadPoolExecutor(jobs) if jobs > 1 else None
        self.jobs = jobs
        # Files to a `goose --multi-test` run (goose_each); 0 chooses by the
        # number of files and jobs.
        self.batch = 0
        self.fronts = {}
        # Slots shown before any section print as they are.
        self.sections = [(None, [])]
        self.gpulock = None
        # What the C that `goose -o` writes links with, built once per
        # configuration by whichever job first asks for it.
        self.runtime = tc.GooseRuntime(exe, tc.REPO_ROOT / "build" / "gen" / "runtime")

    # --- output -----------------------------------------------------------

    def say(self, text):
        """A line of the current piece of work's output, or straight to stdout
        outside one."""
        out = getattr(self.local, "out", None)
        if out is None:
            sys.stdout.write(text + "\n")
        else:
            out.text.append(text + "\n")

    def ok(self, what):
        self.say(f"ok   {what}")

    def fail(self, what, detail=None):
        if detail:
            self.say(detail[:-1] if detail.endswith("\n") else detail)
        self.say(f"FAIL {what}")
        out = getattr(self.local, "out", None)
        if out is None:
            self.failures += 1
        else:
            out.failures += 1

    @contextmanager
    def into(self, out):
        """Prints what runs inside into `out`."""
        prev = getattr(self.local, "out", None)
        self.local.out = out
        try:
            yield out
        finally:
            self.local.out = prev

    def absorb(self, out):
        """Prints what another piece of work printed into `out`, and counts
        its failures, as part of the current one."""
        for line in out.text:
            self.say(line[:-1])
        cur = getattr(self.local, "out", None)
        if cur is None:
            self.failures += out.failures
        else:
            cur.failures += out.failures

    # --- scheduling -------------------------------------------------------

    def submit(self, fn, *args, alone=False):
        """A future of fn(*args), run on the pool, or with `alone` on a
        thread of its own."""
        if self.pool and alone:
            thread = concurrent.futures.ThreadPoolExecutor(1)
            future = thread.submit(fn, *args)
            thread.shutdown(wait=False)
            return future
        if self.pool:
            return self.pool.submit(fn, *args)
        future = concurrent.futures.Future()
        try:
            future.set_result(fn(*args))
        except BaseException as exc:
            future.set_exception(exc)
        return future

    def task(self, fn, *args, alone=False):
        """A future of the Out that fn(*args) prints into, with its result as
        the Out's value."""
        def run():
            out = Out()
            with self.into(out):
                out.value = fn(*args)
            return out
        return self.submit(run, alone=alone)

    def section(self, title):
        """Starts a section of the log: the slots shown from here on, up to
        the next section, print under `title`."""
        self.sections.append((title, []))

    def show(self, source):
        """Adds a slot: a future of an Out, or a callable returning one."""
        self.sections[-1][1].append(source.result if isinstance(source, concurrent.futures.Future)
                                    else source)

    def show_task(self, fn, *args):
        future = self.task(fn, *args)
        self.show(future)
        return future

    def show_later(self, fn, *args):
        """Adds a slot that runs fn(*args) on this thread when the log reaches
        it, once everything shown before it is done: for comparisons and
        summaries over the results of earlier pieces."""
        def run():
            out = Out()
            with self.into(out):
                fn(*args)
            return out
        self.show(run)

    def flush(self):
        """Prints the slots in order, each as soon as it and everything before
        it is done, a section at a time (Section), and adds up their
        failures."""
        for title, slots in self.sections:
            section = Section(title, self.verbose, self.github) if title else None
            for slot in slots:
                try:
                    out = slot()
                except Exception:
                    out = Out()
                    out.text.append(traceback.format_exc())
                    out.text.append("FAIL runner exception\n")
                    out.failures = 1
                if section:
                    section.add(out)
                else:
                    sys.stdout.write("".join(out.text))
                    sys.stdout.flush()
                self.failures += out.failures
            if section:
                section.close()
                self.failed += [(title, line) for line in section.fails]
        self.sections = [(None, [])]

    def finish(self):
        """Prints how the suite went, after the log: the FAIL lines again, by
        section, which under GitHub Actions are also annotations of the run.
        The exit code."""
        if not self.failures:
            print("all tests passed")
            return 0
        print(f"{self.failures} FAILURE(S)" + (":" if self.failed else ""))
        for title, line in self.failed:
            if self.github:
                print("::error::" + f"{title}: {line}".replace("%", "%25"))
            else:
                print(f"{title}: {line}")
        return 1

    # --- running the compiler and what it built ---------------------------

    def goose(self, *args):
        """The compiler under test, as (exit code, stdout, stderr). Both
        streams are captured rather than shown, so a failing step can print
        what happened without having to run the compiler a second time."""
        return self.screened(args[-1], tc.run_capture(self.goose_argv(args)))

    def goose_argv(self, args):
        # Resource-bound regressions use the same runtime configuration
        # through generated C and TinyCC, at every optimization level.
        # --stats for the parsed ok and typechecked ok lines the checks read,
        # after the command where the arguments start with one.
        args = [str(a) for a in args]
        verb = args[:1] if args and not args[0].startswith("-") and len(args) > 1 else []
        return ([self.exe] + verb + ["--stats"] + ["-D" + d for d in runtime_defines(args[-1])] +
                args[len(verb):])

    def screened(self, what, result):
        """A compiler run's result, failing the current piece of work if the
        compiler's sanitizers reported anything."""
        if tc.sanitizer_failure(result[2]):
            self.fail(f"compiler sanitizer {what}", result[2])
        return result

    def goose_each(self, args, files):
        """What goose(*args, f) runs the compiler for, for each of `files`,
        as callables returning its (exit code, stdout, stderr) unscreened:
        the runs happen on the pool, up to `batch` files to one `goose
        --multi-test` (multi_test), and screened() is for whoever uses
        them. A file with runtime defines runs in a plain run of its own,
        as every file does with a `batch` of 1."""
        results = {}
        alone = [f for f in files if self.batch == 1 or runtime_defines(f)]
        together = [f for f in files if f not in alone]
        size = self.batch or max(1, min(32, len(together) // (2 * self.jobs)))
        for i in range(0, len(together), size):
            chunk = together[i:i + size]
            future = self.submit(self.multi_test, args, chunk)
            for f in chunk:
                results[f] = lambda f=f, future=future: future.result()[f]
        for f in alone:
            results[f] = self.submit(tc.run_capture, self.goose_argv([*args, f])).result
        return results

    def multi_test(self, args, files):
        """{f: what `goose *args f` gives} for each of `files`, from one
        `goose --multi-test *args *files` where it got through them: each
        file's part of both streams ends in a line of its own with what the
        file's run would have exited with (MULTIMARK). A run that ends
        before a file's mark, a crash or an abort, gets through the files
        before it; the rest run one to a process, which shows the failure
        as theirs. A batch that exits with an error after every mark, or
        prints anything after the last one (a leak report), gets through
        none."""
        argv = [self.exe, "--multi-test", "--stats"] + [str(a) for a in args] + [str(f) for f in files]
        code, out, err = tc.run_capture(argv)
        outs, outrest = split_multi(out, files)
        errs, errrest = split_multi(err, files)
        done = {}
        for f, (ocode, o), (ecode, e) in zip(files, outs, errs):
            if ocode != ecode:
                break
            done[f] = (ocode, o, e)
        if len(done) == len(files) and (code != 0 or outrest or errrest):
            done = {}
        for f in files:
            if f not in done:
                done[f] = tc.run_capture(self.goose_argv([*args, f]))
        return done

    def run_expected(self, argv, name, label):
        """Run a program and validate it. `argv` is the built executable, or
        the compiler running the program in JIT mode; in both cases stdout is
        the program's alone, since the compiler's own progress lines move to
        stderr when it runs a program."""
        return self.check_run(name, label, *tc.run_capture([str(a) for a in argv]))

    def check_run(self, name, label, code, out, err):
        """Validate termination and diagnostics before comparing stdout."""
        aborts = (HERE / "expected" / f"{name}.aborts").exists()
        if tc.sanitizer_failure(err):
            self.fail(f"sanitizer {label}", err)
            return None
        if (aborts and code == 0) or (not aborts and code != 0):
            self.fail(f"run {label} (exit {code})", err)
            return None
        if not self.check_stderr(name, label, err, required=aborts):
            return None
        return joined(out)

    def check_stderr(self, name, label, err, required=False):
        stderr_file = HERE / "expected" / f"{name}.stderr"
        if required and not stderr_file.exists():
            self.fail(f"missing expected-stderr {label}")
            return False
        if stderr_file.exists():
            markers = [line.strip() for line in tc.decode(stderr_file.read_bytes()).splitlines()
                       if line.strip()]
            if not markers or any(marker not in err for marker in markers):
                self.fail(f"expected-stderr {label}", err)
                return False
        return True

    def check_stdout(self, name, label, out):
        expfile = HERE / "expected" / f"{name}.out"
        if not expfile.exists():
            self.fail(f"missing expected-output {label}")
            return False
        want = joined(tc.decode(expfile.read_bytes()))
        if out != want:
            self.fail(f"expected-output {label}", f"--- got:\n{out}\n--- want:\n{want}")
            return False
        return True

    def check_error(self, path, label, code, out, err):
        # CompileError exits with 1. Signals, access violations and assertion
        # failures are compiler bugs, even if they printed a matching message.
        if code != 1 or tc.sanitizer_failure(err):
            self.fail(f"{label} {path.name} (exit {code})", out + err)
            return False
        markers = error_markers(path)
        # Match diagnostic headers and structural lines -- expansion
        # contexts, the instantiation chain's frames less where they were
        # instantiated from, an overload candidate's reason -- not echoed
        # source (which may itself name the expected message). The
        # missing-main error has no source location.
        diagnostics = []
        for line in err.splitlines():
            match = (re.match(r"^\S.*:\d+(?::\d+)?: error: (.*)$", line) or
                     re.match(r"^  (in (?:fn|thread_fn) .*) instantiated from .*:\d+$", line) or
                     re.match(r"^  candidate \S+ at .*?:\d+: (.*)$", line))
            if match:
                diagnostics.append(match[1])
            elif line.startswith("  in const for "):
                diagnostics.append(line.strip())
            elif line == "program needs exactly one global fn main()":
                diagnostics.append(line)
        diagnostics = "\n".join(diagnostics)
        missing = [m for m in markers if m not in diagnostics]
        if not markers or missing:
            self.fail(f"expected-diagnostic {path.name}",
                      f"missing: {missing or ['// error: marker']}\n{err}")
            return False
        # Checking stops at the error, so which warnings print before it
        # depends on how far it got: a rejection test answers for them only
        # if it declares them.
        return not warning_markers(path) or self.check_warnings(path, out, err)

    def check_warnings(self, path, out, err):
        """The warnings a check printed are the ones the fixture's `// warning:`
        lines declare: one warning line per marker, the marker part of its
        message, in any order. A fixture without markers prints none."""
        # A diagnostic's echoed source is indented, and a warning at no known
        # place is located at "?".
        warnings = [(match[0], match[1]) for match in
                    (re.match(r"\S.*?: warning: (.*)$", line)
                     for line in out.splitlines() + err.splitlines()) if match]
        missing, extra = unmatched_warnings(warning_markers(path), warnings)
        if missing or extra:
            self.fail(f"expected-warnings {path.name}",
                      "".join(f"no warning for marker: {m}\n" for m in missing) +
                      "".join(f"no marker for warning: {w}\n" for w in extra) + out + err)
            return False
        return True

    # --- one positive fixture ---------------------------------------------

    def fixture(self, f):
        """What the suite does with one positive fixture up to its C: the
        front end's checks, then the C at each level, and the program's
        runs through TinyCC, and the C of its dump and debug programs. The
        rest (fixture_runs) follows in a job of its own once the C is
        built, so that the fixture's runs, which may share files the
        program writes, still happen one after another."""
        res = Fixture()
        res.line = line = first_line(f)
        res.sidecar = f.with_suffix(".build").exists() or f.parent.name == "packages"
        bce = has_bce_annotations(f)
        with self.into(res.front):
            res.dumped = self.front(f, line, bce, res)
        if "parse-only" in line:
            if bce:
                with self.into(res.bce):
                    code, out, err = self.goose("-O1", "--check", "--bce-test", f)
                    if code != 0:
                        self.fail(f"bce-test {f.name}", out + err)
                    else:
                        self.ok(f"bce-test {f.name}")
            return res
        self.generate(f, line, res)
        if self.cc and res.dumped:
            with self.into(res.dump):
                res.c["dump"] = self.gendir / f"{f.stem}-dump.c"
                res.gen["dump"] = self.goose("-O2", "-o", res.c["dump"], self.dumpdir / f.name)
        if self.cc and debug_fixture(f, line):
            with self.into(res.debug):
                res.c["debug"] = self.gendir / f"{f.stem}-debug.c"
                res.gen["debug"] = self.goose("-O2", "-o", res.c["debug"], f)
        return res

    def fixture_runs(self, f, generated, builds):
        """The rest of what the suite does with a positive fixture, after
        fixture() (`generated`, its future): build and run its C, and its
        dump and debug programs. `builds` has, by build_options key, a
        future of what build_programs built for a batch of fixtures."""
        res = generated.result()
        line = res.line
        if "parse-only" in line:
            return res
        built = {key: b.result().get(f) for key, b in builds.items()}
        self.programs(f, res, built)
        if self.cc and res.dumped:
            with self.into(res.dump):
                self.dump_program(f, res, built.get("dump"))
        debug = debug_fixture(f, line)
        if self.cc and debug:
            with self.into(res.debug):
                self.debug_program(f, res, built.get("debug"))
        if self.jit and debug and "no-jit" not in line and f.name not in res.jitskips:
            with self.into(res.jitdebug):
                out = self.check_run(f.stem, f"jit-debug {f.name}",
                                     *self.goose("-O2", "--jit", "-DGS_DEBUG=1", f))
                if out is not None and self.check_stdout(f.stem, f"jit-debug {f.name}", out):
                    self.ok(f"jit-debug {f.name}")
        return res

    def front(self, f, line, bce, res):
        """Parses, checks the dump/reparse/dump roundtrip, and typechecks with
        the fixture's warnings, in one compiler run that says how far it got.
        Returns whether the dump was written for a `dump-runtime` run."""
        parseonly = "parse-only" in line
        if "dump-runtime" in line:
            dumpfile = self.dumpdir / f.name
            dumpfile.unlink(missing_ok=True)
            code, out, err = self.goose("--dump-file", dumpfile, *front_args(line, bce), f)
        else:
            dumpfile = None
            code, out, err = self.screened(f, self.fronts[f]())
        text = out + err
        if not re.search(r"^parsed ok:", text, re.M):
            self.fail(f"parse {f.name}", text)
            return False
        if not re.search(r"^roundtrip ok:", text, re.M):
            what = "reparse-of-dump" if "the dump does not parse again" in err else "roundtrip"
            self.fail(f"{what} {f.name}", text)
            return False
        self.ok(f"parse+roundtrip {f.name}")
        if parseonly:
            return bool(dumpfile)
        # A failed annotation is reported after a successful typecheck.
        bcefailed = bce and re.search(r"^bce-test: \d+ annotation failure", err, re.M)
        if not re.search(r"^typechecked ok:", text, re.M) or (code != 0 and not bcefailed):
            self.fail(f"typecheck {f.name}", text)
        elif self.check_warnings(f, out, err):
            self.ok(f"typecheck {f.name}")
        if bce:
            with self.into(res.bce):
                if code != 0:
                    self.fail(f"bce-test {f.name}", text)
                else:
                    self.ok(f"bce-test {f.name}")
        return bool(dumpfile)

    def generate(self, f, line, res):
        """Generates C at each level, and runs the program through TinyCC.
        Where both happen, one compiler run writes the C and runs the
        program in-process: --jit with -o."""
        name = f.stem
        res.modules = modules = native_modules(f, self.native)
        levels = fixture_levels(self.levels, line) if self.cc else ()
        # A native module's fixture runs in-process only where the package
        # is compiled in; the compiler would otherwise build the package.
        available = all(self.native[m] for m in modules)
        res.jitlevels = jitlevels = fixture_levels(("0", "2"), line) if self.jit and available and \
            "no-jit" not in line else ()
        gen, cfiles = res.gen, res.c
        with self.into(res.cgen):
            for ol in sorted(set(levels) | set(jitlevels)):
                args = [f"-O{ol}"]
                if ol in levels:
                    cfiles[ol] = self.gendir / f"{name}-O{ol}.c"
                    cfiles[ol].unlink(missing_ok=True)
                    args += ["-o", cfiles[ol]]
                if ol in jitlevels:
                    args.append("--jit")
                with self.gpu(modules):
                    gen[ol] = self.goose(*args, f)

    def build_options(self, key):
        """How a fixture's C is built: at a level ("0", "2"), its dump's
        ("dump") or its GS_DEBUG build ("debug"). (opt, defines)."""
        if key in ("dump", "debug"):
            return 2 if self.profile == "baseline" else 1, ["GS_DEBUG=1"] if key == "debug" else []
        return int(key) if self.profile == "baseline" else 1, []

    def builds_together(self, res, key):
        """Whether the C a fixture() result wrote for `key` is there to build
        with others': not where it links a native layer, or was not written
        (where a JIT run of it followed, the run has the exit code)."""
        cfile = res.c.get(key)
        if cfile is None or res.modules or res.sidecar:
            return False
        return cfile.is_file() if key in res.jitlevels else res.gen[key][0] == 0

    def build_programs(self, key, generated):
        """Builds the programs that the fixture() futures in `generated`
        (fixture: future) wrote the C of for `key` (build_options) into one
        executable (CC.compile_programs), where there are two or more and
        they build; {fixture: the argv that runs its program} for those."""
        fixtures = [f for f, future in generated.items()
                    if self.builds_together(future.result(), key)]
        if len(fixtures) < 2:
            return {}
        exe = self.gendir / "programs" / f"{fixtures[0].stem}-{key}{tc.EXE_SUFFIX}"
        exe.parent.mkdir(parents=True, exist_ok=True)
        opt, defines = self.build_options(key)
        ok, _ = self.cc.compile_programs([generated[f].result().c[key] for f in fixtures], exe,
                                         opt=opt, defines=defines, extra=self.extra,
                                         strict_decls=True, runtime=self.runtime,
                                         log=exe.with_suffix(".cc.log"))
        return {f: [exe, str(k)] for k, f in enumerate(fixtures)} if ok else {}

    def programs(self, f, res, built):
        """Builds and runs the C generate() wrote at each level, where
        `built` has no argv for it from build_programs, on its own, and
        judges the program's TinyCC runs."""
        name = f.stem
        modules = res.modules
        levels = fixture_levels(self.levels, first_line(f)) if self.cc else ()
        jitlevels, gen, cfiles = res.jitlevels, res.gen, res.c
        if levels:
            with self.into(res.cgen):
                runs, bad = {}, False
                for ol in levels:
                    cfile = cfiles[ol]
                    efile = self.gendir / f"{name}-O{ol}{tc.EXE_SUFFIX}"
                    code, out, err = gen[ol]
                    # A run that went on to run the program has its exit code;
                    # the C is there if the compile got that far.
                    if code != 0 if ol not in jitlevels else not cfile.is_file():
                        self.fail(f"cgen -O{ol} {f.name}", out + err)
                        bad = True
                        continue
                    # A program using a native module still generates C without
                    # the layer; there is just nothing to link it with.
                    if any(not self.native[m] for m in modules):
                        res.nativeskips.append(f.name)
                        bad = True
                        continue
                    argv = built.get(ol)
                    if not argv and (res.sidecar or modules):
                        # A program with C of its own, or using a native
                        # module, is built by the compiler, which builds or
                        # finds that C too (native.h, builtin.h).
                        argv = [efile]
                        code, out, err = tc.run_capture([self.exe, "build", f"-O{ol}", "-o", efile, f])
                        if code != 0:
                            if tc.NO_TOOLCHAIN in err or tc.NO_CMAKE in err:
                                res.nativeskips.append(f.name)
                            else:
                                self.fail(f"goose build -O{ol} {f.name}", out + err)
                            bad = True
                            continue
                    elif not argv:
                        # A program that did not build in a batch shows here
                        # why, built on its own.
                        argv = [efile]
                        opt, _ = self.build_options(ol)
                        ok, log = self.cc.compile(cfile, efile, opt=opt,
                                                  extra=self.extra, strict_decls=True,
                                                  runtime=self.runtime,
                                                  log=self.gendir / f"{name}-O{ol}.cc.log")
                        if not ok:
                            self.fail(f"cc -O{ol} {f.name}", "\n".join(log.splitlines()[:8]))
                            bad = True
                            continue
                    with self.gpu(modules):
                        code, out, err = tc.run_capture(argv)
                    if "gfx" in modules and tc.GFX_NO_DEVICE in err:
                        res.nativeskips.append(f.name)
                        bad = True
                        break
                    out = self.check_run(name, f"-O{ol} {f.name}", code, out, err)
                    if out is None:
                        bad = True
                        continue
                    runs[ol] = out
                if not bad:
                    if len(set(runs.values())) != 1:
                        self.fail(f"cgen-output-differs-by-O {f.name}")
                    elif self.check_stdout(name, f.name, runs["2"]):
                        self.ok(f"cgen+run {f.name}")

        if not self.jit:
            return
        if any(not self.native[m] for m in modules):
            if f.name not in res.nativeskips:
                res.nativeskips.append(f.name)
            return
        if not jitlevels:
            res.jitskips.append(f.name)
            return
        with self.into(res.jit):
            runs, bad = {}, False
            for ol in jitlevels:
                code, out, err = gen[ol]
                # A refusal is the backend saying the program needs something
                # it does not have yet, which is a gap to report, not a failure
                # of this test.
                if code != 0 and tc.JIT_UNSUPPORTED in err:
                    res.jitskips.append(f.name)
                    return
                if any(tc.native_unavailable(m, err) for m in modules) or \
                        (code != 0 and (tc.NO_TOOLCHAIN in err or tc.NO_CMAKE in err)):
                    res.nativeskips.append(f.name)
                    return
                out = self.check_run(name, f"jit -O{ol} {f.name}", code, out, err)
                if out is None:
                    bad = True
                    continue
                runs[ol] = out
            if bad:
                return
            if len(set(runs.values())) != 1:
                self.fail(f"jit-output-differs-by-O {f.name}")
            elif self.check_stdout(name, f"jit {f.name}", runs["2"]):
                self.ok(f"jit {f.name}")

    def dump_program(self, f, res, argv):
        """A stable dump can still change grouping and therefore semantics:
        the dumped program runs against the original expectations. Its C is
        from fixture(); `argv` runs it where build_programs built it."""
        dumpfile = self.dumpdir / f.name
        code, out, err = res.gen["dump"]
        if code != 0:
            self.fail(f"cgen-dump {dumpfile.name}", out + err)
            return
        if not argv:
            argv = [self.gendir / f"{f.stem}-dump{tc.EXE_SUFFIX}"]
            opt, defines = self.build_options("dump")
            ok, log = self.cc.compile(res.c["dump"], argv[0], opt=opt, defines=defines,
                                      extra=self.extra, strict_decls=True, runtime=self.runtime,
                                      log=self.gendir / f"{f.stem}-dump.cc.log")
            if not ok:
                self.fail(f"cc-dump {dumpfile.name}", log)
                return
        out = self.run_expected(argv, f.stem, f"dump {dumpfile.name}")
        if out is not None and self.check_stdout(f.stem, f"dump {dumpfile.name}", out):
            self.ok(f"dump+run {dumpfile.name}")

    def debug_program(self, f, res, argv):
        """GS_DEBUG changes language overflow/cast checks, independently of
        native optimization: its helpers under O2. The C is from fixture();
        `argv` runs it where build_programs built it."""
        name = f.stem
        code, out, err = res.gen["debug"]
        if code != 0:
            self.fail(f"cgen-debug {f.name}", out + err)
            return
        if not argv:
            argv = [self.gendir / f"{name}-debug{tc.EXE_SUFFIX}"]
            opt, defines = self.build_options("debug")
            ok, log = self.cc.compile(res.c["debug"], argv[0], opt=opt, defines=defines,
                                      extra=self.extra, strict_decls=True, runtime=self.runtime,
                                      log=self.gendir / f"{name}-debug.cc.log")
            if not ok:
                self.fail(f"cgen-debug-cc {f.name}", "\n".join(log.splitlines()[:8]))
                return
        out = self.run_expected(argv, name, f"debug {f.name}")
        if out is not None and self.check_stdout(name, f"debug {f.name}", out):
            self.ok(f"cgen-debug {f.name}")

    @contextmanager
    def gpu(self, modules):
        """Holds the GPU for a program using gfx, where --gpu-jobs limits how
        many of those run at once."""
        if "gfx" not in modules or self.gpulock is None:
            yield
            return
        with self.gpulock:
            yield

    def check_optimizer(self, level, specs):
        # Observe the transformed bodies, rather than accepting a successful
        # --specs command or pinning unstable specialization IDs/pass counts.
        bodies = {}
        for spec in specs.split("// spec ")[1:]:
            match = re.search(r"^fn ((?:tre|gb)_\w+)\([^\n]*\) \{\n", spec, re.MULTILINE)
            if match:
                bodies[match[1]] = spec[match.end():]
        optimized = level != "-O0"
        shapes = {
            "tre_add": (optimized, not optimized),
            "tre_rev": (optimized, not optimized),
            "tre_plain": (optimized, not optimized),
            "tre_mixed": (optimized, True),
            "tre_mod": (False, True),
            "tre_flt": (False, True),
            "tre_from": (False, True),
            "tre_inloop": (False, True),
            "tre_walk": (optimized, not optimized),
            "tre_local": (False, True),
            "tre_and": (optimized, not optimized),
        }
        valid = True
        for name, want in shapes.items():
            body = bodies.get(name)
            got = None if body is None else (
                bool(re.search(r"\bloop \{", body)),
                bool(re.search(rf"\b{name}\(", body)),
            )
            if got != want:
                self.fail(f"tail-recursion {level} {name}",
                          f"(loop, self call): got {got}, want {want}")
                valid = False
        # A u64 above i64.max that the optimizer makes -- a fold, a tail loop's
        # accumulator start -- dumps as that value, not as its bits signed.
        want = ["18446744073709539270"] + (["var acc = 18446744073709551615;"] if optimized else [])
        missing = [w for w in want if w not in specs]
        if missing or "-12346" in specs:
            self.fail(f"u64 constants {level}", f"missing {missing} or a signed -12346")
            valid = False
        # Guarded base-case inlining: a copy of the body's first statement
        # per self-call site the rewrite took.
        copies = {
            "gb_callback": 3 if optimized else 1,
            "gb_build": 3 if optimized else 1,
            "gb_walk": 2 if optimized else 1,
            "gb_count": 3 if optimized else 1,
            "gb_arena": 3 if optimized else 1,
            "gb_method": 3 if optimized else 1,
            "gb_global": 1,
            "gb_field": 1,
            "gb_arith": 1,
            "gb_var": 1,
        }
        for name, want in copies.items():
            body = bodies.get(name)
            got = None if body is None else body.count("gb_visits += 1;")
            if got != want:
                self.fail(f"guarded base case {level} {name}",
                          f"copies of the body's start: got {got}, want {want}")
                valid = False
        # Min/max chains: ra_edit's alone is regrouped, its operands bound in
        # the order written and the carried operand2 combined last.
        bound = re.findall(r"\blet (operand\d+) = ", specs)
        combined = re.findall(r"\blet [ab] = (operand\d+);", specs)
        want = (["operand1", "operand2", "operand3"], ["operand1", "operand3", "operand2"]) \
            if optimized else ([], [])
        if (bound, combined) != want:
            self.fail(f"min/max chains {level}",
                      f"(bound, combined): got {(bound, combined)}, want {want}")
            valid = False
        # Inlining heuristics: which bodies are left out of line.
        live = set(re.findall(r"^(?:inline )?fn (i[hl]_\w+)\(", specs, re.MULTILINE))
        left = {
            "ih_rare": True,
            "ih_early": True,
            "ih_check": not optimized,
            "ih_wrap": not optimized,
            "ih_twin": True,
            "ih_key": not optimized,
            "ih_slow": True,
            "ih_front": True,
            "ih_work": not optimized,
            # inline fn: inlined however big, and whatever function value
            # it takes; its twin without the keyword stays; one returning
            # two values stays a call in Goose.
            "il_big": not optimized,
            "il_plain": True,
            "il_pair": True,
            "il_apply": not optimized,
        }
        for name, want in left.items():
            if (name in live) != want:
                self.fail(f"inlining heuristics {level} {name}",
                          f"left out of line: got {name in live}, want {want}")
                valid = False
        return valid

    def check_abandoned_accumulator(self, level, specs):
        bodies = {}
        for spec in specs.split("// spec ")[1:]:
            match = re.search(r"^fn (\w+)\([^\n]*\) \{\n", spec, re.MULTILINE)
            if match:
                bodies[match[1]] = spec[match.end():]
        optimized = level != "-O0"
        shapes = {
            "leave_arg": (False, True),
            "leave_block": (optimized, True),
            "leave_mixed": (optimized, True),
            "leave_sequence": (optimized, True),
            "safe_block": (optimized, not optimized),
            "safe_plain_block": (optimized, not optimized),
        }
        valid = True
        for name, want in shapes.items():
            body = bodies.get(name)
            got = None if body is None else (
                bool(re.search(r"\bloop \{", body)),
                bool(re.search(rf"\b{name}\(", body)),
            )
            if got != want:
                self.fail(f"abandoned-accumulator {level} {name}",
                          f"(loop, self call): got {got}, want {want}")
                valid = False
        return valid

    def check_loop_shapes(self, text):
        # The loops codegen restates mark themselves in the C with a comment
        # naming the shape (optimize_loops.h, BCE's lenbound). Every shape_
        # function of the fixture must have the one it is named for, and no
        # keep_ function any.
        bodies = {}
        texts = {}
        for m in re.finditer(r"^static [^\n;]*?\b((?:shape|keep)_\w+?)_g\d*\([^\n]*\) \{\n(.*?)^\}\n",
                             text, re.MULTILINE | re.DOTALL):
            bodies[m[1]] = re.findall(r"/\* loop shape: ([^*]*?) \*/", m[2])
            texts[m[1]] = m[2]
        strip = "strip-mined by"
        sums = "sum terms in blocks of 8"
        bound = "trip count bounded by"
        down = "countdown counted up"
        shapes = {
            "shape_strip_lanes": f"{strip} 8", "shape_strip_count": f"{strip} 4",
            "shape_strip_range": f"{strip} 3", "shape_strip_u8": f"{strip} 16",
            "shape_strip_return": f"{strip} 4", "shape_strip_structs": f"{strip} 2",
            "shape_strip_fixed": f"{strip} 4", "shape_strip_div": f"{strip} 4",
            "shape_sum_dot": sums, "shape_sum_count": sums, "shape_sum_f32": sums,
            "shape_sum_range": sums, "shape_sum_spec": sums, "keep_sum_reads": None,
            "shape_sum_whole": sums, "shape_sum_ragged": sums, "shape_sum_fixed": sums,
            "shape_bound_count": f"{bound} 8", "shape_bound_any": f"{bound} 8",
            "shape_bound_all": f"{bound} 8", "shape_bound_for": f"{bound} 6",
            "shape_bound_grow": f"{bound} 8",
            "shape_down": down, "shape_down_u8": down, "shape_down_i8": down,
            "shape_down_u64": down, "shape_down_jumps": down, "keep_down_twice": None,
        }
        valid = True
        for name, want in shapes.items():
            got = bodies.get(name)
            if got is None:
                self.fail(f"loop shapes {name}", "no C function of its own (inlined?)")
                valid = False
            elif (want not in got) if want else got:
                self.fail(f"loop shapes {name}", f"got {got}, want {want or 'none'}")
                valid = False
        # Both copies of a body run in blocks divide by the magic number of a
        # divisor the loop cannot change (HoistDivisors), never by the divisor.
        body = texts.get("shape_strip_div", "")
        if "gs_divu32_q(" not in body or re.search(r"\bgs_(?:div|mod)_u32\(", body):
            self.fail("loop shapes shape_strip_div", "a division not by the divisor's magic number")
            valid = False
        # From 0 to a constant multiple of the block size, the blocks run every
        # iteration and there is no loop for the rest (CodeGen::GenBlocked,
        # #210); any other count, constant or not, keeps it.
        tails = {
            "shape_sum_whole": False, "shape_sum_fixed": False, "shape_sum_ragged": True,
            "shape_sum_count": True, "shape_sum_dot": True, "shape_strip_fixed": True,
        }
        for name, want in tails.items():
            got = bool(re.search(r"^\s*for \(; ", texts.get(name, ""), re.MULTILINE))
            if got != want:
                self.fail(f"loop shapes {name}",
                          f"loop for the rest: got {got}, want {want}")
                valid = False
        # A && or || condition is a chain of branches (CodeGen::GenBranch):
        # neither the 0/1 flag the right operand sets inside an `if`, which
        # a value keeps, nor the two flags combined with & or | of a loop that
        # can be straight-line code (§6.11), nor an inlined bool call's result
        # held for the branch (or the call left a call).
        def forms(body):
            got = set()
            if re.search(r"uint8_t (t\d+) = \(uint8_t\)\([^\n]* != 0\);\n\s*if \(!?\1\) \{", body):
                got.add("flag")
            if re.search(r"\(uint8_t\)\(t\d+ [&|] \(uint8_t\)\(", body):
                got.add("speculative")
            if (re.search(r"^\s*uint8_t (t\d+);\n(?:.*\n)*?\s*if \(!?\(?\1\)?\) ", body, re.M)
                    or re.search(r"\bclean_g\d*\(", body)):
                got.add("call")
            return got
        chains = {
            "shape_chain_while": set(), "shape_chain_skip": set(), "shape_chain_if": set(),
            "shape_chain_guard": set(), "shape_chain_order": set(), "shape_chain_call": set(),
            "keep_chain_value": {"flag"}, "keep_chain_spec": {"speculative"},
            "shape_sum_spec": {"speculative"},
        }
        for name, want in chains.items():
            if name not in texts:
                self.fail(f"loop shapes {name}", "no C function of its own (inlined?)")
                valid = False
            elif forms(texts[name]) != want:
                self.fail(f"loop shapes {name}",
                          f"got {sorted(forms(texts[name])) or 'branches'}, want {sorted(want) or 'branches'}")
                valid = False
        return valid

    # --- the Goose-written compiler ---------------------------------------

    def goose_in_goose(self, cc, profile, extra, jit):
        """Exercise the compiler as a large program, then execute its output.

        Stage 1 comes from the compiler under test; each subsequent stage is
        emitted by the preceding executable from the same Goose sources.
        All native stages use the selected toolchain/profile, including the
        sanitizer flags. These modules are not standalone output fixtures.

        The chain of stages at each level, and the JIT self-compile at each,
        are jobs of their own, started here; what this returns adds their
        slots, and those of the comparisons between them, to the log."""
        source = HERE / "goose_in_goose" / "main.goose"
        directory = tc.REPO_ROOT / "build" / "gen" / profile / "goose_in_goose"

        # Generated compilers need the same stack budget as the host. Only
        # the child's soft limit is raised, by the shell that starts it: the
        # suite process keeps its own, and a preexec_fn is not safe with the
        # suite's threads.
        stack_prefix = []
        if sys.platform.startswith("linux"):
            import resource
            soft, hard = resource.getrlimit(resource.RLIMIT_STACK)
            target = 64 * 1024 * 1024
            if hard != resource.RLIM_INFINITY:
                target = min(target, hard)
            if soft != resource.RLIM_INFINITY and soft < target:
                stack_prefix = ["sh", "-c", f'ulimit -S -s {target // 1024} && exec "$@"', "sh"]

        def run(argv, label, log):
            try:
                # The -O0 chain is the suite's critical path; on Windows its
                # compilers run ahead of the work around them.
                result = subprocess.run(stack_prefix + [str(a) for a in argv], cwd=tc.REPO_ROOT,
                                        capture_output=True, timeout=180,
                                        creationflags=getattr(subprocess,
                                                              "ABOVE_NORMAL_PRIORITY_CLASS", 0))
                code, out, err = result.returncode, tc.decode(result.stdout), tc.decode(result.stderr)
            except subprocess.TimeoutExpired as exc:
                code, out, err = -1, tc.decode(exc.stdout or b""), tc.decode(exc.stderr or b"") + "\n180s timeout"
            except OSError as exc:
                code, out, err = -1, "", str(exc)
            tc.write_text(log, f"exit {code}\n{out}{err}")
            if code != 0 or tc.sanitizer_failure(err):
                self.fail(f"{label} (exit {code}; log: {log})", out + err)
                return None
            self.ok(label)
            return out

        stack_flags = []
        if cc:
            if cc.style == "msvc":
                stack_flags = ["/F67108864"]
            elif tc.IS_WINDOWS:
                # A gcc-style Clang driver can still use the MSVC linker.
                _, target, _ = tc.run_capture([cc.cc, "-dumpmachine"])
                stack_flags = ["-Wl,/STACK:67108864"] if "msvc" in target else ["-Wl,--stack,67108864"]
            elif tc.IS_MACOS:
                stack_flags = ["-Wl,-stack_size,0x4000000"]

        def self_check(compiler, label, log):
            """Repeated compilations also exercise context cleanup in the
            built compiler, without pinning internal counts."""
            out = run([compiler, "--check-many", source, source], f"self-check {label} stage 2", log)
            if out is not None:
                lines = out.splitlines()
                if (len(lines) != 2 or lines[0] != lines[1] or
                        not re.fullmatch(r"checked \d+ specializations, \d+ types", lines[0])):
                    self.fail(f"repeated self-check output {label}", out)

        def chain(ol):
            """The native stages at one level; the stage-2 C, when they all
            built."""
            label = f"goose_in_goose -O{ol}"
            work = directory / f"O{ol}"
            work.mkdir(parents=True, exist_ok=True)
            if not cc:
                run([self.exe, f"-O{ol}", "--check", source], f"typecheck {label}", work / "host.check.log")
                return None
            checks = []
            try:
                return stages(ol, label, work, checks)
            finally:
                for check in checks:
                    self.absorb(check.result())

        def stages(ol, label, work, checks):
            compiler = self.exe
            cfiles = []
            for stage in range(1, 4):
                cfile = work / f"stage{stage}.c"
                executable = work / f"stage{stage}{tc.EXE_SUFFIX}"
                cfile.unlink(missing_ok=True)
                executable.unlink(missing_ok=True)
                flags = [f"-O{ol}"] if stage == 1 else []
                what = f"{label} stage {stage}"
                if run([compiler, *flags, "-o", cfile, source], f"emit {what}",
                       work / f"stage{stage}.emit.log") is None:
                    return None
                if not cfile.is_file() or not cfile.stat().st_size:
                    self.fail(f"missing or empty C output {what}")
                    return None
                # Later stages hold the Goose-written compiler's own runtime.
                ok, log = cc.compile(cfile, executable, opt=ol if profile == "baseline" else 1,
                                     extra=[*extra, *stack_flags], strict_decls=True,
                                     runtime=self.runtime if stage == 1 else None,
                                     log=work / f"stage{stage}.cc.log")
                if not ok:
                    self.fail(f"cc {what}", log)
                    return None
                self.ok(f"cc {what}")
                cfiles.append(cfile)
                compiler = executable
                # Stage 3 is built from the same C as stage 2 (the fixed
                # point below), so stage 2 self-checks for both, while stage 3
                # is emitted and built: the -O0 chain is the suite's critical
                # path.
                if stage == 2:
                    checks.append(self.task(self_check, executable, label,
                                            work / "stage2.check.log", alone=True))
            native_c = cfiles[1].read_bytes()
            if native_c != cfiles[2].read_bytes():
                self.fail(f"fixed point {label}", f"C differs: {cfiles[1]} vs {cfiles[2]}")
            else:
                self.ok(f"fixed point {label} ({len(native_c)} bytes)")
            return native_c

        def jit_self_compile(ol):
            """The Goose-written compiler run through TinyCC, compiling
            itself; the C it wrote."""
            label = f"goose_in_goose -O{ol}"
            work = directory / f"O{ol}"
            work.mkdir(parents=True, exist_ok=True)
            cfile = work / "jit-stage2.c"
            cfile.unlink(missing_ok=True)
            out = run([self.exe, f"-O{ol}", "--jit", source, "--", "-o", cfile, source],
                      f"JIT self-compile {label}", work / "jit.emit.log")
            if out is None:
                return None
            if not cfile.is_file() or not cfile.stat().st_size:
                self.fail(f"missing or empty JIT C output {label}")
                return None
            return cfile.read_bytes()

        levels = (0, 2) if profile == "baseline" else (2,)
        chains = {ol: self.task(chain, ol) for ol in levels}
        jits = {ol: self.task(jit_self_compile, ol) for ol in levels} if jit else {}

        def compare_jit(ol):
            jit_c, native_c = jits[ol].result().value, chains[ol].result().value
            if jit_c is not None and native_c is not None:
                if jit_c != native_c:
                    self.fail(f"JIT/native self-compile differs goose_in_goose -O{ol}")
                else:
                    self.ok(f"JIT/native self-compile matches goose_in_goose -O{ol}")

        def compare_levels():
            outputs = [chains[ol].result().value for ol in levels]
            if len(outputs) == 2 and None not in outputs:
                if outputs[0] != outputs[1]:
                    self.fail("goose_in_goose self-compile differs between O0 and O2")
                else:
                    self.ok("goose_in_goose self-compile matches between O0 and O2")

        def show():
            self.section("goose_in_goose bootstrap")
            if not cc:
                self.show_later(self.say, "skip native goose_in_goose bootstrap "
                                          "(no C compiler found or --nocgen)")
            for ol in levels:
                self.show(chains[ol])
                if jit:
                    self.show(jits[ol])
                    self.show_later(compare_jit, ol)
            self.show_later(compare_levels)
        return show


def default_jobs():
    """One job per logical processor, up to 32: the C compiler stops getting
    faster well before that, and the rest of the work is mostly short
    processes."""
    return min(os.cpu_count() or 1, 32)


def main():
    ap = argparse.ArgumentParser(description=__doc__,
                                 formatter_class=argparse.RawDescriptionHelpFormatter)
    ap.add_argument("--exe", help="the goose compiler to test")
    ap.add_argument("--nocgen", action="store_true",
                    help="skip everything that needs a C compiler")
    ap.add_argument("--profile", choices=("baseline", "sanitize"), default="baseline",
                    help="baseline: native O0/O2; sanitize: Linux Clang ASan/UBSan at O1")
    ap.add_argument("--cc", choices=("native", "clang", "gcc", "msvc"),
                    help="require this C toolchain instead of optional auto-discovery")
    ap.add_argument("--require-clang", action="store_true",
                    help="fail if the baseline's second C-front-end check is unavailable")
    ap.add_argument("--no-jit", action="store_true",
                    help="skip the in-process TinyCC runs even where they are available")
    ap.add_argument("--goose-in-goose-only", action="store_true",
                    help="run only the multi-stage Goose-written compiler regression")
    ap.add_argument("-j", "--jobs", type=int, default=default_jobs(),
                    help=f"how many jobs run at once (default {default_jobs()}); "
                         "1 runs everything in order on one thread")
    ap.add_argument("--gpu-jobs", type=int, default=0,
                    help="how many gfx programs run at once (default: no limit "
                         "beyond --jobs)")
    ap.add_argument("--batch", type=int, default=0,
                    help="how many files one `goose --multi-test` run checks, and how "
                         "many programs one executable holds (default: by the number of "
                         "files and jobs); 1 gives each a process and an executable of "
                         "its own")
    ap.add_argument("-v", "--verbose", action="store_true",
                    help="print a line for every check that passed, not only each "
                         "section's count of them")
    args = ap.parse_args()

    if args.nocgen and (args.cc or args.require_clang or args.profile != "baseline"):
        ap.error("--nocgen cannot be combined with a required toolchain or sanitizer profile")
    if args.profile == "sanitize" and (not sys.platform.startswith("linux") or
                                        args.cc not in (None, "clang")):
        ap.error("the sanitize profile requires Linux and Clang")
    if args.jobs < 1 or args.gpu_jobs < 0 or args.batch < 0:
        ap.error("--jobs must be at least 1, and --gpu-jobs and --batch at least 0")

    tc.setup_console()
    # The compiler's cache (runtime objects, fetched packages) for everything
    # the suite runs: under the build tree, never the user's own.
    os.environ["GOOSE_HOME"] = str(tc.REPO_ROOT / "build" / "goose-home")
    started = time.perf_counter()
    # The suite opens no windows: a gfx program asking for one draws off
    # screen instead.
    os.environ["GOOSE_GFX_HEADLESS"] = "1"
    exe = tc.find_goose(args.exe)
    # Everything that changes this process's environment (vcvars) or writes
    # a shared file (the JIT probe) happens here, before any job starts.
    cc = None if args.nocgen else tc.test_cc("clang" if args.profile == "sanitize" else args.cc)
    extra = tc.SANITIZER_FLAGS if args.profile == "sanitize" else ()
    if args.profile == "sanitize":
        tc.use_sanitizer_suppressions()
    # Not under the sanitizers: the program runs inside the compiler process and
    # is not itself instrumented, and its runtime allocations are still held
    # when the compiler exits, which LeakSanitizer reports against the compiler.
    jit = not args.no_jit and args.profile != "sanitize"
    r = Runner(exe, args.jobs, args.verbose)
    r.gpulock = threading.BoundedSemaphore(args.gpu_jobs) if args.gpu_jobs else None
    r.batch = args.batch

    # The bootstrap is the longest chain of work in the suite, so it starts
    # first, and the samples' runner, a process of its own, next.
    show_goose_in_goose = r.goose_in_goose(cc, args.profile, extra, jit)
    if args.goose_in_goose_only:
        show_goose_in_goose()
        r.flush()
        return r.finish()

    # The samples: compiled, built, run and compared with their expected output
    # (or only typechecked without a C compiler), by their own runner, with
    # as many jobs as this one.
    sargs = [sys.executable, str(tc.REPO_ROOT / "samples" / "run_samples.py"),
             "--exe", str(exe), "--jobs", str(args.jobs)]
    if args.gpu_jobs:
        sargs += ["--gpu-jobs", str(args.gpu_jobs)]
    if not jit:
        sargs.append("--no-jit")
    if args.nocgen:
        sargs.append("--nocgen")
    else:
        sargs += ["--profile", args.profile]
        if args.cc:
            sargs += ["--cc", args.cc]

    def samples():
        result = subprocess.run(sargs, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        # The section's count says what the runner's last line would.
        lines = [line for line in tc.decode(result.stdout).splitlines()
                 if line != "all samples passed"]
        if lines:
            r.say("\n".join(lines))
        if result.returncode != 0:
            r.local.out.failures += max(1, sum(line.startswith("FAIL ") for line in lines))
    # On a thread of its own rather than one of the pool's, which it would
    # keep waiting the whole time.
    samples_future = r.task(samples, alone=True)

    clang = None if args.nocgen or args.profile == "sanitize" else tc.find_clang_c()
    if args.require_clang and not clang:
        ap.error("requested secondary C front end is unavailable: clang")
    # Which native modules (by a fixture's category directory and what it
    # imports) have their package compiled into the compiler: a fixture using
    # one that is not only generates C, so that the suite never has the
    # compiler fetch and build a package.
    builtin = tc.builtin_modules(exe)
    native = {m: m in builtin for m in tc.NATIVE_MODULES}
    print(f"profile: {args.profile}; C backend: {cc.desc if cc else 'none'}; "
          f"JIT backend: {'TinyCC' if jit else 'none'}; " +
          "; ".join(f"{m}: {'built in' if have else 'not built in'}" for m, have in native.items()))
    builddir = tc.REPO_ROOT / "build"
    builddir.mkdir(parents=True, exist_ok=True)
    dumpdir = builddir / "dump"
    dumpdir.mkdir(parents=True, exist_ok=True)
    gendir = builddir / "gen" / args.profile
    gendir.mkdir(parents=True, exist_ok=True)
    r.cc, r.native, r.profile, r.extra, r.jit = cc, native, args.profile, extra, jit
    r.levels = ("0", "2") if args.profile == "baseline" else ("2",)
    r.gendir, r.dumpdir = gendir, dumpdir
    deepdir = gendir

    # The language reference's examples, compiled and (through the JIT) run
    # by their own checker, which reports a FAIL line per block that does not
    # compile or print what the document shows, and a summary line last.
    dargs = [sys.executable, str(tc.REPO_ROOT / "scripts" / "check_doc_examples.py"),
             str(tc.REPO_ROOT / "docs" / "reference.md"), "--exe", str(exe),
             "--jobs", str(args.jobs), "--out-dir", str(gendir / "doc_examples")]
    if jit:
        dargs.append("--run")

    def doc_examples():
        result = subprocess.run(dargs, stdout=subprocess.PIPE, stderr=subprocess.STDOUT)
        lines = tc.decode(result.stdout).splitlines()
        if result.returncode == 0 and lines:
            r.ok("reference examples: " + lines[-1])
        else:
            r.say("\n".join(lines) if lines else "the checker printed nothing")
            r.local.out.failures += max(1, sum(line.startswith("FAIL ") for line in lines))
    doc_examples_future = r.task(doc_examples, alone=True)

    # One level of category directories; nested syntax helpers and the modules
    # of the goose_in_goose bootstrap are exercised through their entry points.
    # The lsp/ fixtures are the language server's, driven by lsp_protocol.py.
    tests = [f for f in sorted(HERE.glob("*/*.goose"))
             if f.parent.name not in ("errors", "errors_tc", "goose_in_goose", "lsp") and
             f.name != "lexer_tokens.goose"]
    if len({f.stem for f in tests}) != len(tests):
        ap.error("fixture names must be unique across categories (shared expected/ and build outputs)")
    # A native module's (audio, gfx, physics or ui) fixture with error markers
    # is a rejection test, kept beside what it rejects (for gfx, shaders).
    native_errors = [f for f in tests if f.parent.name in native and error_markers(f)]
    tests = [f for f in tests if f not in native_errors]

    # The generated programs below take long to check; they start before the
    # fixtures. Their files are written here, before any job reads them.
    call_chain_file = deepdir / "call_chain.goose"
    tc.write_text(call_chain_file, call_chain(2000))
    too_deep_file = deepdir / "call_chain_too_deep.goose"
    tc.write_text(too_deep_file, "// error: compile-time call path too deep\n" +
                  call_chain(6000, nest=32))
    guard_runs_file = deepdir / "guard_runs.goose"
    tc.write_text(guard_runs_file, guard_runs(300, 200))

    # The typechecker checks a function inside the call that first reaches it,
    # so its native stack grows with the compile-time call path, which a
    # program can make as long as it likes. A chain of 2000 distinct functions
    # checks and runs. At -O2 the inliner folds its single-use functions into
    # one body per 64 levels of C blocks: one body as deep as the chain would
    # cost time and memory quadratic in its length, and C that MSVC rejects
    # past 128 levels and clang past 256. A chain of 6000 that calls each next
    # function from 32 blocks deep takes more stack than any build of the
    # compiler has, a clang -O3 one holding about 2500 of those calls, and is
    # an error rather than a crash.
    def call_chain_checks():
        f = call_chain_file
        code, out, err = r.goose("-O0", "--check", f)
        if code != 0:
            r.fail(f"typecheck {f.name}", out + err)
        else:
            r.ok(f"typecheck {f.name}")
        if jit:
            code, out, err = r.goose("-O0", "--jit", f)
            if code != 0 or joined(out) != "3":
                r.fail(f"jit {f.name} (exit {code})", out + err)
            else:
                r.ok(f"jit {f.name}")
        if cc:
            cfile = deepdir / "call_chain-O2.c"
            efile = deepdir / f"call_chain-O2{tc.EXE_SUFFIX}"
            code, out, err = r.goose("-O2", "-o", cfile, f)
            if code != 0:
                r.fail(f"cgen -O2 {f.name}", out + err)
            else:
                ok, log = cc.compile(cfile, efile, opt=2 if args.profile == "baseline" else 1,
                                     extra=extra, strict_decls=True, runtime=r.runtime,
                                     log=deepdir / "call_chain-O2.cc.log")
                if not ok:
                    r.fail(f"cc -O2 {f.name}", "\n".join(log.splitlines()[:8]))
                else:
                    code, out, err = tc.run_capture([efile])
                    if code != 0 or joined(out) != "3":
                        r.fail(f"run -O2 {f.name} (exit {code})", out + err)
                    else:
                        r.ok(f"cgen+run -O2 {f.name}")

    def call_chain_too_deep():
        f = too_deep_file
        code, out, err = r.goose("-O0", "--check", f)
        if r.check_error(f, "expected-tc-error", code, out, err):
            r.ok(f"tc-error {f.name}")

    # A guard is an if over the rest of its block (§6.4), whose rest codegen
    # emits after the else rather than in a C block of its own where the else
    # leaves, so 300 guards in a row build with MSVC, which stops at 128
    # levels of blocks, and with clang, at 256. The inliner counts no block
    # for such a rest either: a chain of calls, each behind four guards,
    # folds into bodies MAXNEST (64) levels deep, which blocks opened by
    # codegen but not counted by the inliner would make over 300 deep.
    def guard_runs_level(ol):
        f = guard_runs_file
        cfile = deepdir / f"guard_runs-O{ol}.c"
        efile = deepdir / f"guard_runs-O{ol}{tc.EXE_SUFFIX}"
        code, out, err = r.goose(f"-O{ol}", "-o", cfile, f)
        if code != 0:
            r.fail(f"cgen -O{ol} {f.name}", out + err)
            return
        ok, log = cc.compile(cfile, efile, opt=int(ol) if args.profile == "baseline" else 1,
                             extra=extra, strict_decls=True, runtime=r.runtime,
                             log=deepdir / f"guard_runs-O{ol}.cc.log")
        if not ok:
            r.fail(f"cc -O{ol} {f.name}", "\n".join(log.splitlines()[:8]))
            return
        code, out, err = tc.run_capture([efile])
        if code != 0 or joined(out) != "299 -1 5 3":
            r.fail(f"run -O{ol} {f.name} (exit {code})", out + err)
        else:
            r.ok(f"cgen+run -O{ol} {f.name}")

    deep = [r.task(call_chain_checks), r.task(call_chain_too_deep)]
    deep += [r.task(guard_runs_level, ol) for ol in (r.levels if cc else ())]

    # The fixtures' parse, roundtrip and typecheck runs, in batches by their
    # flags, start before the rest of each fixture, which waits for them.
    fronts = {}
    for f in tests:
        line = first_line(f)
        if "dump-runtime" not in line:
            fronts.setdefault(tuple(front_args(line, has_bce_annotations(f))), []).append(f)
    for args_, files in fronts.items():
        r.fronts.update(r.goose_each(list(args_), files))
    # The fixtures that take longest, those building and running graphics,
    # physics or ui programs, start first.
    order = sorted(tests, key=lambda f: not native_modules(f, native))
    generated = {f: r.submit(r.fixture, f) for f in order}
    # The C of the other fixtures builds in batches, each kind of build
    # (build_options) by itself, and the rest of each fixture follows once
    # its batches are built.
    builds = {}
    plain = [f for f in order if not native_modules(f, native)]
    kinds = {ol: [f for f in plain if "parse-only" not in first_line(f)] for ol in r.levels}
    kinds["dump"] = [f for f in plain if "dump-runtime" in first_line(f)]
    kinds["debug"] = [f for f in plain if debug_fixture(f, first_line(f))]
    for key, together in kinds.items() if cc and r.batch != 1 else ():
        size = r.batch or max(2, min(32, len(together) // (2 * args.jobs)))
        for i in range(0, len(together), size):
            chunk = {f: generated[f] for f in together[i:i + size]}
            future = r.submit(r.build_programs, key, chunk)
            for f in chunk:
                builds.setdefault(f, {})[key] = future
    fixtures = {f: r.submit(r.fixture_runs, f, generated[f], builds.get(f, {})) for f in order}

    # --- what the log shows, in order ---------------------------------------

    r.section("lexer and shader compiler")

    def lexer_tokens():
        code, out, err = r.goose("--tokens", HERE / "syntax" / "lexer_tokens.goose")
        if code != 0:
            r.fail("lex lexer_tokens.goose", out + err)
        elif r.check_stdout("lexer_tokens", "lexer_tokens.goose", joined(out)):
            r.ok("lex lexer_tokens.goose")
    r.show_task(lexer_tokens)

    # The shader compiler is built into every compiler, SDL or not: a shader
    # compiles, #include included, and a binding outside SDL_GPU's sets is
    # rejected with the rule it broke.
    def shader_probe():
        code, out, err = r.goose("--compile-shader", HERE / "gfx" / "probe.frag")
        want = "samplers 1, storage textures 0 ro / 0 rw, storage buffers 0 ro / 0 rw, uniform blocks 1 (32 bytes)"
        if code != 0 or want not in out:
            r.fail("compile-shader probe.frag", out + err)
        else:
            r.ok("compile-shader probe.frag")

    def shader_badset():
        code, out, err = r.goose("--compile-shader", HERE / "gfx" / "probe_badset.frag")
        if code != 1 or "sampler 'tex' is in set 0, and must be in set 2" not in err:
            r.fail("compile-shader probe_badset.frag", out + err)
        else:
            r.ok("compile-shader probe_badset.frag")
    r.show_task(shader_probe)
    r.show_task(shader_badset)

    # An error in shader source written in the program is reported at its own
    # line of the program: the one using `oops` in these fixtures.
    def shader_error_line(name):
        f = HERE / "gfx" / f"{name}.goose"
        lines = f.read_text(encoding="utf-8").splitlines()
        at = next(i for i, text in enumerate(lines, 1) if "oops" in text and not text.startswith("//"))
        code, out, err = r.goose("--check", f)
        if code != 1 or f"{f.name}:{at}: error: embed_shader: undeclared identifier 'oops'" not in err:
            r.fail(f"shader error line {f.name}", out + err)
        else:
            r.ok(f"shader error line {f.name}")
    for name in ("gfx_err_shader_syntax", "gfx_err_shader_part"):
        r.show_task(shader_error_line, name)

    r.section("parse, roundtrip and typecheck")
    for f in tests:
        r.show(lambda f=f: fixtures[f].result().front)

    # The optimizer runs in every typecheck above, at -O1 for bce annotations
    # and -O2 otherwise; also exercise every level (and the --specs dump path)
    # on the optimizer coverage file.
    r.section("optimizer, stack report and C shapes")

    def optimize(lvl):
        code, out, err = r.goose(lvl, "--check", "--specs", HERE / "optimizer" / "optimize.goose")
        if code != 0:
            r.fail(f"optimize {lvl}", out + err)
        elif r.check_optimizer(lvl, out):
            r.ok(f"optimize {lvl}")
    for lvl in ("-O0", "-O1", "-O2"):
        r.show_task(optimize, lvl)

    def abandoned_accumulator(lvl):
        code, out, err = r.goose(lvl, "--check", "--specs",
                                 HERE / "optimizer" / "tre_abandoned_accumulator.goose")
        if code != 0:
            r.fail(f"abandoned-accumulator {lvl}", out + err)
        elif r.check_abandoned_accumulator(lvl, out):
            r.ok(f"abandoned-accumulator {lvl}")
    for lvl in ("-O0", "-O1", "-O2"):
        r.show_task(abandoned_accumulator, lvl)

    # The data stack report (--stacks): a program with a worker, whose
    # first-line budget caps the workers at one, a recursive one whose
    # first-line GS_MAX_STACKS the compiler checks the count against, and one
    # whose worker only puts a fixed value: it holds no regions, which caps
    # nothing. The counts themselves follow the emitted code and are not
    # pinned, other than that worker's none.
    def stacks_report(f, patterns):
        # The report goes where the compiler's messages do: without an -o,
        # stderr where it has TinyCC to run the program, stdout where it
        # would write the .c instead.
        code, out, err = r.goose("-O1", "--check", "--stacks", f)
        missing = [p for p in patterns
                   if not any(re.search(p, s, re.MULTILINE) for s in (out, err))]
        if code != 0 or missing:
            r.fail(f"stacks {f.name}", f"missing {missing}\n{out}{err}")
        else:
            r.ok(f"stacks {f.name}")
    r.show_task(stacks_report, HERE / "threads" / "thread_cap.goose", [
        r"^data stacks: 2 GB reserved per stack, 1 MB guard gap, 4 GB budget: 1 regions, GS_MAX_STACKS 1024$",
        r"^main program: \d+ data stacks \+ 0 global stacks = \d+ regions$",
        r"^worker `worker`: [1-9]\d* data stacks \+ 0 argument and global stacks = \d+ regions$",
        r"^thread cap: 1 workers \(\(1 - \d+\) / \d+\), what hardware_threads\(\) reports at most$",
        r"^fn worker: [1-9]\d* own, \d+ with callees$",
    ])
    r.show_task(stacks_report, HERE / "codegen" / "cycle_scratch_locals.goose", [
        r"^data stacks: .*, GS_MAX_STACKS 4$",
        r"^main program: [1-4] data stacks \+ 0 global stacks = [1-4] regions$",
        r"^thread cap: none, no workers$",
        r"^fn in_block: [1-9]\d* own, [1-4] with callees$",
    ])
    r.show_task(stacks_report, HERE / "threads" / "thread_spawn_discarded.goose", [
        r"^worker `worker`: 0 data stacks \+ 0 argument and global stacks = 0 regions$",
        r"^thread cap: none, no worker holds a region$",
    ])
    # The loops codegen restates, read in the C of their fixture, where -O1
    # keeps each function a C function of its own.
    def loop_shapes():
        f = HERE / "optimizer" / "loop_shapes.goose"
        cfile = gendir / "loop_shapes-shapes.c"
        code, out, err = r.goose("-O1", "-o", cfile, f)
        if code != 0:
            r.fail(f"loop shapes {f.name}", out + err)
        elif r.check_loop_shapes(cfile.read_text()):
            r.ok(f"loop shapes {f.name}")
    r.show_task(loop_shapes)
    # An inline fn returning two values stays a call in Goose and is declared
    # GS_INLINE in the C, for the C compiler to inline (§7.13).
    def inline_fn_c():
        f = HERE / "optimizer" / "optimize.goose"
        cfile = gendir / "optimize-inline.c"
        code, out, err = r.goose("-O1", "-o", cfile, f)
        if code != 0:
            r.fail("inline fn C", out + err)
            return
        text = cfile.read_text()
        pair = re.search(r"^static GS_INLINE [^\n;]*\bil_pair_g\d*\(", text, re.MULTILINE)
        plain = re.search(r"^static GS_INLINE [^\n;]*\bil_plain_g\d*\(", text, re.MULTILINE)
        if not pair or plain:
            r.fail("inline fn C", f"il_pair GS_INLINE: {bool(pair)}, il_plain GS_INLINE: {bool(plain)}")
        else:
            r.ok("inline fn C")
    r.show_task(inline_fn_c)
    # A slice and a builder parameter are two C parameters each (spec C.3),
    # the slice's data pointer as `void *` (ParamFields).
    def member_params():
        f = HERE / "codegen" / "member_parameters.goose"
        cfile = gendir / "member_parameters-sig.c"
        code, out, err = r.goose("-O1", "-o", cfile, f)
        if code != 0:
            r.fail(f"member parameters {f.name}", out + err)
            return
        sig = re.search(r"^static void walk_g\w*\(([^)]*)\) \{$", cfile.read_text(),
                        re.MULTILINE)
        want = (r"void \*\w+, int64_t \w+, gs_i64 \w+, gs_rhdr \*\w+, gs_stack \*\w+, "
                r"void \*\w+, int64_t \w+")
        if not sig or not re.fullmatch(want, sig[1]):
            r.fail(f"member parameters {f.name}",
                   f"walk's parameters: got {sig[1] if sig else None}")
        else:
            r.ok(f"member parameters {f.name}")
    r.show_task(member_params)
    # A large fixed variable at its only use is the callee's argument itself
    # (CodeGen::SingleUses, MovableArg); one read again, or read through a
    # reference or a deferred body, or used in a loop it is declared outside
    # of, is copied first. At -O0, which inlines nothing.
    def last_use_moves():
        f = HERE / "codegen" / "last_use_moves.goose"
        cfile = gendir / "last_use_moves-shapes.c"
        code, out, err = r.goose("-O0", "-o", cfile, f)
        if code != 0:
            r.fail(f"last-use moves {f.name}", out + err)
            return
        text = cfile.read_text()
        def given(fn, var):
            return re.search(rf"\b{fn}_g\(&\(\*{var}_g\)[,)]", text) is not None
        # ("spoil", "d") is pass_on's parameter handed on.
        moved = [("bump", "a"), ("spoil", "dl"), ("spoil", "d")]
        copied = [("bump", "b"), ("spoil", "c"), ("bump", "c"), ("spoil", "e"),
                  ("both", "h"), ("spoil", "j"), ("pass_on", "m"), ("read_after", "m"),
                  ("spoil", "n"), ("spoil", "q"), ("spoil", "w"), ("spoil", "ix"),
                  ("spoil", "px"), ("spoil", "sx"), ("spoil", "dx"), ("spoil2", "cx")]
        wrong = [f"{fn}({v}) not given" for fn, v in moved if not given(fn, v)]
        wrong += [f"{fn}({v}) given" for fn, v in copied if given(fn, v)]
        if wrong:
            r.fail(f"last-use moves {f.name}", ", ".join(wrong))
        else:
            r.ok(f"last-use moves {f.name}")
    r.show_task(last_use_moves)
    # Root descriptors expose ordinary component metadata to top caching and
    # loop-view hoisting, even when Goose leaves the helper out of line.
    def root_owner_caches():
        cfile = gendir / "root_owner_caches-shapes.c"
        code, out, err = r.goose("-O0", "-o", cfile, HERE / "codegen" / "root_owner_caches.goose")
        if code != 0:
            r.fail("root owner caches", out + err)
            return
        text = cfile.read_text()
        def body(name):
            match = re.search(rf"^static [^\n;]*\b{name}_g\w*\([^\n]*\) \{{\n(.*?)^\}}\n",
                              text, re.MULTILINE | re.DOTALL)
            return match[1] if match else ""
        grow, summation = body("grow"), body("sum")
        prefix, _, loop = grow.partition("for (")
        cached = all(re.search(rf"uint8_t \*\w+ = .*\.{f}_g\.stk->top;", prefix)
                     and re.search(rf"int64_t \w+ = .*\.{f}_g\.hdr->len;", prefix)
                     for f in ("first", "second"))
        hoisted = all(s in summation.partition("for (")[0] for s in ("hdr->base", "hdr->len"))
        # All header reads/writes in grow's loop use the caches, and sum's
        # indexed load no longer goes through a descriptor or bounds check.
        growth_body = loop.partition("\n    }")[0]
        read_body = summation.partition("for (")[2].partition("\n    }")[0]
        if not cached or not hoisted or "hdr->" in growth_body or "hdr->" in read_body:
            r.fail("root owner caches", grow + summation)
        else:
            r.ok("root owner caches")
    r.show_task(root_owner_caches)
    def bulk_default_loops():
        cfile = gendir / "bulk-default-loops-shapes.c"
        code, out, err = r.goose("-O0", "-o", cfile, HERE / "codegen" / "bulk_default_loops.goose")
        if code != 0:
            r.fail("bulk default loops", out + err)
            return
        text = cfile.read_text()
        bodies = re.findall(r"^static [^\n;]*\b(?:grow|fill)_g\w*\([^\n]*\) \{\n(.*?)^\}\n",
                            text, re.MULTILINE | re.DOTALL)
        bulk = [b for b in bodies if "GS_MEMZERO" in b and "for (" not in b]
        effects = [b for b in bodies if "next_g" in b and "for (" in b]
        if len(bulk) != 4 or len(effects) != 2:
            r.fail("bulk default loops", "\n".join(bodies))
        else:
            r.ok("bulk default loops")
    r.show_task(bulk_default_loops)
    # Inlined helpers and chains of immutable root aliases keep one spelling
    # of each component. This caller remains out of line (multiple results).
    def root_alias_caches():
        cfile = gendir / "root_alias_caches-shapes.c"
        code, out, err = r.goose("-O2", "-o", cfile, HERE / "codegen" / "root_alias_caches.goose")
        if code != 0:
            r.fail("root alias caches", out + err)
            return
        text = cfile.read_text()
        match = re.search(r"^static [^\n;]*\bgrow_g\w*\([^\n]*\) \{\n(.*?)^\}\n",
                          text, re.MULTILINE | re.DOTALL)
        body = match[1] if match else ""
        prefix, _, loop = body.partition("for (")
        cached = all(re.search(rf"uint8_t \*\w+ = .*\.{f}_g\.stk->top;", prefix)
                     and re.search(rf"int64_t \w+ = .*\.{f}_g\.hdr->len;", prefix)
                     for f in ("first", "second"))
        # No aliases or metadata traffic in the inlined loop; bounds/runtime
        # checks elsewhere are unaffected by this representation change.
        loop = loop.partition("\n    }")[0]
        if not cached or "hdr->" in loop or "stk->" in loop or "State_g *" in loop:
            r.fail("root alias caches", body)
        else:
            r.ok("root alias caches")
    r.show_task(root_alias_caches)
    # A known owner survives out-of-line calls and recursive forwarding;
    # merged, mutable and local owners still use the descriptor interface.
    def root_call_identity():
        for opt in (0, 2):
            cfile = gendir / f"root_call_identity-O{opt}-shapes.c"
            code, out, err = r.goose(f"-O{opt}", "-o", cfile, HERE / "codegen" / "root_call_identity.goose")
            if code != 0:
                r.fail(f"root call identity O{opt}", out + err)
                continue
            text = cfile.read_text()
            def bodies(name):
                return re.findall(rf"^static [^\n;]*\b{name}_g\w*\([^\n]*\) \{{\n(.*?)^\}}\n",
                                  text, re.MULTILINE | re.DOTALL)
            direct = bodies("known") + bodies("descend")
            generic = bodies("shared") + bodies("shared_recursive") + bodies("dynamic")
            if (len(direct) < 2 or not all("gs_component_one_g_" in b and "hdr->" not in b for b in direct)
                    or len(generic) < 3 or not all("hdr->" in b for b in generic)):
                r.fail(f"root call identity O{opt}", "\n".join(direct + generic))
            else:
                r.ok(f"root call identity O{opt}")
    r.show_task(root_call_identity)
    def root_call_caches():
        cfile = gendir / "root_call_caches-shapes.c"
        code, out, err = r.goose("-O2", "-o", cfile, HERE / "codegen" / "root_call_caches.goose")
        if code != 0:
            r.fail("root call caches", out + err)
            return
        text = cfile.read_text()
        def body(name):
            match = re.search(rf"^static [^\n;]*\b{name}_g\w*\([^\n]*\) \{{\n(.*?)^\}}\n",
                              text, re.MULTILINE | re.DOTALL)
            return match[1] if match else ""
        ok = True
        for name in ("pair", "direct"):
            prefix, _, loop = body(name).partition("for (")
            ok &= len(re.findall(r"uint8_t \*\w+ = .*->top;", prefix)) == 1
            ok &= len(re.findall(r"int64_t \w+ = .*\.len;", prefix)) == 1
            ok &= "GS_GL" not in loop.partition("\n    }")[0]
        outer = body("outer")
        before, call, after = outer.partition(" = inner_g(")
        ok &= bool(call)
        for component in (0, 1):
            stack = rf"\(&GS_GL->gs_gstk_gs_component_state_g_{component}\)->top"
            length = rf"GS_GL->gs_component_state_g_{component}\.len"
            ok &= bool(re.search(stack + r" = \w+;", before) and re.search(length + r" = \w+;", before))
            ok &= bool(re.search(r"\w+ = " + stack + ";", after) and re.search(r"\w+ = " + length + ";", after))
        mixed = body("mixed").partition("for (")[2].partition("\n    }")[0]
        ok &= "gs_gstk_gs_component_state_g_0)->top" in mixed and ".stk->top" in mixed
        if ok:
            r.ok("root call caches")
        else:
            r.fail("root call caches", "\n".join(body(n) for n in ("pair", "outer", "mixed", "direct")))
    r.show_task(root_call_caches)
    # A root reference the callee only projects or forwards arrives as its
    # descriptor's members; one it returns, stores or captures, or that is
    # forwarded to such a callee, as the descriptor's address.
    def root_split_params():
        for opt in (0, 2):
            cfile = gendir / f"root_split_params-O{opt}-shapes.c"
            code, out, err = r.goose(f"-O{opt}", "-o", cfile, HERE / "codegen" / "root_split_params.goose")
            if code != 0:
                r.fail(f"root split params O{opt}", out + err)
                continue
            text = cfile.read_text()
            sigs = {m[1]: m[2] for m in re.finditer(r"^static [^\n;(]*\b(\w+?)_g(?:_\d+)?\(([^\n]*)\) \{$",
                                                    text, re.MULTILINE)}
            split = ("fill", "forward", "aliased", "deep")
            whole = ("via_same", "stored", "captured")
            ok = all(n in sigs and "_first_g_hdr" in sigs[n] and "r_S_g" not in sigs[n] for n in split)
            ok &= all(n in sigs and "r_S_g s_g" in sigs[n] and "_first_g_hdr" not in sigs[n] for n in whole)
            if ok:
                r.ok(f"root split params O{opt}")
            else:
                r.fail(f"root split params O{opt}", "\n".join(f"{n}: {s}" for n, s in sigs.items()))
    r.show_task(root_split_params)
    # Fields nothing can move are member stores, not stores through a
    # pointer taken first (StableDest).
    def member_stores():
        f = HERE / "codegen" / "member_stores.goose"
        cfile = gendir / "member_stores-c.c"
        code, out, err = r.goose("-O1", "-o", cfile, f)
        if code != 0:
            r.fail(f"member stores {f.name}", out + err)
            return
        body = re.search(r"^static void store_links_g\w*\([^\n]*\) \{\n(.*?)^\}\n",
                         cfile.read_text(), re.MULTILINE | re.DOTALL)
        stores = body and all(re.search(rf"\)\.{fld}_g = ", body[1]) for fld in ("w", "prev"))
        if not stores or re.search(r"gs_f64 \*t\d+ = &", body[1]):
            r.fail(f"member stores {f.name}", body[1] if body else "no store_links in the C")
        else:
            r.ok(f"member stores {f.name}")
    r.show_task(member_stores)
    # A constant array of listed elements is static data at any length, and
    # a long fill keeps its runtime initialization (MAXSTATICELEMS), in a
    # static of its own outside the globals struct.
    def static_arrays():
        f = HERE / "codegen" / "const_global_folding.goose"
        cfile = gendir / "const_global_folding-static.c"
        code, out, err = r.goose("-O1", "-o", cfile, f)
        if code != 0:
            r.fail(f"static arrays {f.name}", out + err)
            return
        text = cfile.read_text()
        listed = re.search(r"^static const a260_i64 LONG_g\w* = ", text, re.MULTILINE)
        filled = re.search(r"^static a300_i64 FILLED_g\w*;$", text, re.MULTILINE)
        if not listed or not filled or "GS_GL->FILLED_g" in text:
            r.fail(f"static arrays {f.name}",
                   f"LONG static: {bool(listed)}, FILLED shared: {bool(filled)}")
        else:
            r.ok(f"static arrays {f.name}")
    r.show_task(static_arrays)
    # A constant fill or string past MAXSTATICELEMS is a static of its own,
    # read in place by every worker rather than copied at spawn (§11.2).
    def shared_fills():
        f = HERE / "threads" / "thread_shared_fills.goose"
        cfile = gendir / "thread_shared_fills-shared.c"
        code, out, err = r.goose("-O1", "-o", cfile, f)
        if code != 0:
            r.fail(f"shared fills {f.name}", out + err)
            return
        text = cfile.read_text()
        bad = [n for n in ("TABLE", "ZEROS", "TEXT")
               if not re.search(rf"^static \w+ {n}_g\w*;$", text, re.MULTILINE) or
                  f"GS_GL->{n}_g" in text]
        if bad:
            r.fail(f"shared fills {f.name}", "copied or not static: " + ", ".join(bad))
        else:
            r.ok(f"shared fills {f.name}")
    r.show_task(shared_fills)

    # Every annotated regression, including the expected-abort cases. These
    # describe the O1 pass; O0/O2 execution checks semantics.
    r.section("bounds-check annotations")
    for f in tests:
        r.show(lambda f=f: fixtures[f].result().bce)

    # --- codegen: generate C, compile, run, compare ------------------------
    def native_skips():
        skipped = [name for f in tests for name in fixtures[f].result().nativeskips]
        if skipped:
            r.say(f"skip running {len(set(skipped))} audio, gfx, physics or ui test(s) (no "
                  f"layer for them, or no GPU device): " + ", ".join(sorted(set(skipped))))

    r.section("generated C, built and run at " + " and ".join(f"-O{ol}" for ol in r.levels))
    if not cc:
        r.show_later(r.say, "skip codegen run tests (no C compiler found or --nocgen)")
    for f in tests if cc else ():
        r.show(lambda f=f: fixtures[f].result().cgen)
    r.show_later(native_skips)
    if cc:
        for kind, title in (("dump", "dump-runtime programs"), ("debug", "GS_DEBUG programs")):
            r.section(title)
            for f in tests:
                r.show(lambda f=f, kind=kind: getattr(fixtures[f].result(), kind))

        r.section("compiler roots, runtime lifecycle and clang")

        # Algebraic properties of the compiler's root domain are easier to
        # exhaust over small abstract states than to express in Goose, and
        # its containers to compare with the standard ones directly.
        def compiler_unit(name, sources=(), flags=()):
            out_exe = gendir / f"{name}{tc.EXE_SUFFIX}"
            ok, log = cc.compile([HERE / f"{name}.cpp", *sources], out_exe, cpp=True,
                                 opt=2 if args.profile == "baseline" else 1,
                                 extra=[*extra, *flags], log=gendir / f"{name}.cc.log")
            if not ok:
                r.fail(f"compiler-cc {name}", log)
            else:
                code, out, err = tc.run_capture([out_exe])
                if code != 0 or tc.sanitizer_failure(err):
                    r.fail(f"compiler {name}", out + err)
                else:
                    r.ok(f"compiler {name}")
        for name in ("compiler_roots", "compiler_containers"):
            r.show_task(compiler_unit, name)
        r.show_task(compiler_unit, "compiler_process",
                    [HERE.parent / "src" / name for name in ("process.cpp", "progress.cpp")],
                    [("/I" if cc.style == "msvc" else "-I") +
                     str(HERE.parent / "third_party" / "subprocess")])

        # Direct runtime lifecycle checks use small region limits and allocator
        # instrumentation that cannot be expressed by a Goose program. Keep
        # these focused native tests in both profiles.
        def runtime_lifecycle(name, directory):
            src = HERE / directory / f"{name}.c"
            out_exe = gendir / f"{name}{tc.EXE_SUFFIX}"
            ok, log = cc.compile(src, out_exe, opt=2 if args.profile == "baseline" else 1,
                                 extra=extra, strict_decls=True,
                                 log=gendir / f"{name}.cc.log")
            if not ok:
                r.fail(f"runtime-cc {name}", log)
            else:
                out = r.run_expected([out_exe], name, name)
                if out is not None and r.check_stdout(name, name, out):
                    r.ok(f"runtime {name}")
        r.show_task(runtime_lifecycle, "runtime_threads_lifecycle", "threads")
        r.show_task(runtime_lifecycle, "runtime_trim_memory", "runtime")

        # A library build's C host: goose_exit ends the program and goose_init
        # starts it again over fresh globals and queues, and ending it while a
        # worker still runs is a runtime error.
        def host_exit():
            src = HERE / "threads" / "host_exit.goose"
            cfile = gendir / "host_exit.c"
            code, out, err = r.goose("-O1", "--header", gendir / "host_exit.h", "-o", cfile, src)
            if code != 0:
                r.fail("host-exit cgen host_exit.goose", out + err)
                return
            # Beside the header it includes.
            host = gendir / "host_exit_main.c"
            shutil.copyfile(HERE / "threads" / "host_exit.c", host)
            out_exe = gendir / f"host_exit{tc.EXE_SUFFIX}"
            ok, log = cc.compile([host, cfile], out_exe, opt=1, extra=extra, strict_decls=True,
                                 runtime=r.runtime, log=gendir / "host_exit.cc.log")
            if not ok:
                r.fail("host-exit cc host_exit", "\n".join(log.splitlines()[:8]))
                return
            for name, argv in (("host_exit_c", []), ("host_exit_live", ["live"])):
                out = r.run_expected([out_exe] + argv, name, name)
                if out is not None and r.check_stdout(name, name, out):
                    r.ok(f"host {name}")
        r.show_task(host_exit)

        # The same coverage test through clang, release and debug. A compiler
        # that accepts more C than the standard does is not what checks the
        # generated C is actually valid: a call to a function defined only in
        # debug builds compiled silently under MSVC and broke every clang
        # release build.
        def clang_codegen():
            src = gendir / "cgclang.c"
            code, out, err = r.goose("-O2", "-o", src, HERE / "codegen" / "codegen_exec.goose")
            if code != 0:
                r.fail("cgen-clang codegen_exec.goose", out + err)
                return
            for label in ("release", "debug"):
                out_exe = gendir / f"cgclang-{label}{tc.EXE_SUFFIX}"
                ok, log = clang.compile(src, out_exe, opt=1, warn="off", strict_decls=True,
                                        defines=["GS_DEBUG=1"] if label == "debug" else [],
                                        runtime=r.runtime, log=gendir / f"cgclang-{label}.log")
                if not ok:
                    r.fail(f"cgen-clang-{label} codegen_exec.goose",
                           "\n".join(log.splitlines()[:8]))
                    continue
                out = r.run_expected([out_exe], "codegen_exec", f"clang-{label} codegen_exec.goose")
                if out is not None and r.check_stdout("codegen_exec", f"clang-{label}", out):
                    r.ok(f"cgen-clang-{label} codegen_exec.goose")
        # The versions of the simd functions (spec §7.12) exist only where
        # clang builds for x86-64: each level the C may be built for runs
        # here, at -O2 so the loops vectorize, and has to print what the
        # baseline does. On a CPU without AVX-512 or AVX2 the higher builds
        # run the highest version it has, which is still a version.
        # simd_versions.goose covers the language's side; the stdlib fixtures
        # check the library's simd functions, as clang builds them.
        def clang_simd_versions(ctext):
            # Every simd function keeps its versions, the single-use ones the
            # optimizer would otherwise inline and the element-run twin too.
            # The generic total has two specializations, numbered.
            missing = [f for f in ("caesar_g", "checksum_g", "muladd_g", "squares_g", "minmax_g",
                                   "biased_g", "fib_g", "sum3_g", "squares_g_er")
                       if f"{f}_simd1(" not in ctext or f"{f}_simd2(" not in ctext]
            if len(set(re.findall(r"\b(total_g_\d+)_simd[12]\(", ctext))) != 2:
                missing.append("total_g")
            return missing

        def clang_simd_named(*names):
            # A C name may carry a specialization's number after the module's.
            def missing(ctext):
                return [f for f in names
                        if not re.search(rf"\b{f}_g\d+(_\d+)?_simd1\(", ctext)
                        or not re.search(rf"\b{f}_g\d+(_\d+)?_simd2\(", ctext)]
            return missing

        def clang_simd(name, path, versions):
            src = gendir / f"simdclang-{name}.c"
            code, out, err = r.goose("-O2", "-o", src, path)
            if code != 0:
                r.fail(f"simd-clang {name}.goose", out + err)
                return
            missing = versions(src.read_text(encoding="utf-8"))
            if missing:
                r.fail(f"simd-clang {name}.goose", f"no simd versions of {', '.join(missing)}")
                return
            for level in ("2", "1", "0"):
                label = f"simd{level}"
                out_exe = gendir / f"simdclang-{name}-{level}{tc.EXE_SUFFIX}"
                ok, log = clang.compile(src, out_exe, opt=2, warn="off", strict_decls=True,
                                        defines=[f"GS_SIMD={level}"], runtime=r.runtime,
                                        log=gendir / f"simdclang-{name}-{level}.log")
                if not ok:
                    r.fail(f"{label}-clang {name}.goose", "\n".join(log.splitlines()[:8]))
                    continue
                out = r.run_expected([out_exe], name, f"clang-{label} {name}.goose")
                if out is not None and r.check_stdout(name, f"clang-{label}", out):
                    r.ok(f"{label}-clang {name}.goose")
        # math's mul_add is the one result a simd function's versions may give
        # differently from its baseline (spec §7.12): rounded once where the
        # code is built for FMA. Built by clang at each level, a plain
        # function rounds as the target does (once on arm64, twice on a plain
        # x86-64 build) and the simd function's versions round once, which on
        # x86-64 a CPU with AVX2 and FMA runs at levels 1 and 2. Where the CPU
        # can't be asked, levels 1 and 2 may give either.
        def host_fma():
            if tc.IS_WINDOWS:
                try:
                    import ctypes
                    # PF_AVX2_INSTRUCTIONS_AVAILABLE; every CPU with AVX2
                    # this runs on has FMA.
                    return bool(ctypes.windll.kernel32.IsProcessorFeaturePresent(40))
                except (AttributeError, OSError):
                    return None
            if sys.platform.startswith("linux"):
                try:
                    flags = set()
                    for line in open("/proc/cpuinfo", encoding="utf-8"):
                        if line.startswith("flags"):
                            flags.update(line.split(":", 1)[1].split())
                            break
                    return "avx2" in flags and "fma" in flags
                except OSError:
                    return None
            return None

        def clang_mul_add():
            name = "simd_mul_add"
            arm = platform.machine().lower() in ("arm64", "aarch64")
            fma = host_fma()
            # The program reports five calls: a plain function's, then in a
            # simd function a direct call, an inline helper's, a plain
            # helper's and one through a function value. At Goose -O2 the
            # helpers are inlined (the plain one may or may not be); at -O0
            # nothing is, and both keep the plain function's rounding.
            for gopt in ("-O2", "-O0"):
                tag = gopt[1:].lower()
                src = gendir / f"muladdclang-{tag}.c"
                code, out, err = r.goose(gopt, "-o", src, HERE / "codegen" / f"{name}.goose")
                if code != 0:
                    r.fail(f"mul_add-clang{gopt} {name}.goose", out + err)
                    continue
                ctext = src.read_text(encoding="utf-8")
                if not re.search(r"#define GS_MUL_ADD_MODE fused\nGS_SIMD_TARGET1 static [^\n]*"
                                 r"\bdirect_g\w*_simd1\(", ctext):
                    r.fail(f"mul_add-clang{gopt} {name}.goose", "no fused mode around the AVX2 version")
                    continue
                for level in ("2", "1", "0"):
                    label = f"mul_add-simd{level}-clang{gopt} {name}.goose"
                    out_exe = gendir / f"muladdclang-{tag}-{level}{tc.EXE_SUFFIX}"
                    ok, log = clang.compile(src, out_exe, opt=2, warn="off", strict_decls=True,
                                            defines=[f"GS_SIMD={level}"], runtime=r.runtime,
                                            log=gendir / f"muladdclang-{tag}-{level}.log")
                    if not ok:
                        r.fail(label, "\n".join(log.splitlines()[:8]))
                        continue
                    out = r.check_run(name, label, *tc.run_capture([out_exe, "modes"]))
                    if out is None:
                        continue
                    lines = out.splitlines()
                    got = lines[-1].split() if lines else []
                    plain = {"fused" if arm else "separate"}
                    simd = ({"fused"} if arm else {"separate"} if level == "0" else
                            {"fused", "separate"} if fma is None else {"fused" if fma else "separate"})
                    inlined = simd if gopt == "-O2" else plain
                    want = [plain, simd, inlined, simd | plain if gopt == "-O2" else plain, simd]
                    if len(lines) != 2 or lines[0] != "true" or len(got) != len(want) or                             any(g not in w for g, w in zip(got, want)):
                        r.fail(label, f"got {out!r}; want " +
                               " ".join("|".join(sorted(w)) for w in want))
                    else:
                        r.ok(label)

        # Elementwise float arithmetic as one vector operation (GS_VEC,
        # runtime.h): vec_elemwise's struct and array shapes are computed
        # through each of the six vector types where the compiler has vector
        # extensions, and nothing else is. Built by clang with GS_VEC on and
        # off, both print the member-by-member results.
        def clang_vec():
            name = "vec_elemwise"
            src = gendir / "vecclang.c"
            code, out, err = r.goose("-O2", "-o", src, HERE / "codegen" / f"{name}.goose")
            if code != 0:
                r.fail(f"vec-clang {name}.goose", out + err)
                return
            ctext = src.read_text(encoding="utf-8")
            missing = [v for v in ("gs_vf64_2", "gs_vf64_4", "gs_vf64_8", "gs_vf32_4", "gs_vf32_8", "gs_vf32_16")
                       if f"GS_VST({v}," not in ctext]
            if missing:
                r.fail(f"vec-clang {name}.goose", f"no vector operations on {', '.join(missing)}")
                return
            # The generated code's tests are indented; runtime.h's are not.
            opens = len(re.findall(r"^\s+#if GS_VEC$", ctext, re.M))
            elses = len(re.findall(r"^\s+#else$", ctext, re.M))
            if opens == 0 or opens > elses:
                r.fail(f"vec-clang {name}.goose", f"{opens} vector operations, {elses} member-by-member ones")
                return
            for on in ("1", "0"):
                label = f"vec{on}"
                out_exe = gendir / f"vecclang-{on}{tc.EXE_SUFFIX}"
                ok, log = clang.compile(src, out_exe, opt=2, warn="off", strict_decls=True,
                                        defines=[f"GS_VEC={on}"], runtime=r.runtime,
                                        log=gendir / f"vecclang-{on}.log")
                if not ok:
                    r.fail(f"{label}-clang {name}.goose", "\n".join(log.splitlines()[:8]))
                    continue
                out = r.run_expected([out_exe], name, f"clang-{label} {name}.goose")
                if out is not None and r.check_stdout(name, f"clang-{label}", out):
                    r.ok(f"{label}-clang {name}.goose")

        if args.profile == "sanitize":
            pass  # The full generated-C suite already ran through Clang.
        elif not clang:
            r.show_later(r.say, "skip cgen-clang (no clang found)")
        else:
            r.show_task(clang_codegen)
            r.show_task(clang_simd, "simd_versions", HERE / "codegen" / "simd_versions.goose",
                        clang_simd_versions)
            r.show_task(clang_simd, "stdlib_base64", HERE / "stdlib" / "stdlib_base64.goose",
                        clang_simd_named("base64_encode", "base64_decode"))
            r.show_task(clang_mul_add)
            r.show_task(clang_vec)

    r.section("driver, diagnostics and language server")

    def driver_verbs():
        """The verb forms of the command line against the flag forms they
        stand for: `goose run`, `goose check` and `goose version`, the help, a
        mistyped command, --color, --stats, the completion scripts and the
        man page."""
        probe = gendir / "verbs.goose"
        tc.write_text(probe, 'fn main() { print("verbs"); }\n')
        checks = []
        if jit:
            code, out, err = tc.run_capture([exe, "run", probe])
            checks.append(("run", code == 0 and out.strip() == "verbs", out + err))
        code, out, err = tc.run_capture([exe, "check", probe])
        checks.append(("check", code == 0 and not out and not err, out + err))
        code, out, err = tc.run_capture([exe, "check", "--stats", probe])
        checks.append(("check --stats", code == 0 and "typechecked ok" in out + err and
                       "verbs" not in out, out + err))
        code, out, err = tc.run_capture([exe, "run", "-o", str(gendir / "verbs.c"), probe])
        checks.append(("run -o (refused)", code != 0 and "takes no -o" in err, out + err))
        version = re.compile(r"goose \S+ \(runtime [0-9a-f]{12}\)\s*$")
        code, out, err = tc.run_capture([exe, "version"])
        checks.append(("version", code == 0 and version.match(out) is not None, out + err))
        code, out2, err = tc.run_capture([exe, "--version"])
        checks.append(("--version", code == 0 and out2 == out, out2 + err))
        # A word that is no command, option or file is a mistyped command.
        code, out, err = tc.run_capture([exe, "biuld", str(probe)])
        checks.append(("a mistyped command", code == 1 and "unknown command biuld" in err and
                       "did you mean build?" in err, out + err))
        code, out, err = tc.run_capture([exe, "nosuch.goose"])
        checks.append(("a missing file", code == 1 and "cannot open file" in err, out + err))
        # --color always colors an error, and NO_COLOR, or output that is no
        # terminal, colors nothing.
        bad = gendir / "verbs_bad.goose"
        tc.write_text(bad, "fn main() {\n    let y = (;\n}\n")
        code, out, err = tc.run_capture([exe, "check", "--color", "always", bad])
        checks.append(("--color always", code == 1 and "\x1b[1;31merror: \x1b[0m" in err and
                       "\x1b[1;32m^\x1b[0m" in err, repr(err)))
        code, out, err = tc.run_capture([exe, "check", bad])
        checks.append(("no color off a terminal", code == 1 and "\x1b" not in err and
                       "error: expression expected" in err, repr(err)))
        nocolor = subprocess.run([str(exe), "check", bad], capture_output=True,
                                 env=dict(os.environ, NO_COLOR="1", CLICOLOR_FORCE="1"))
        checks.append(("NO_COLOR", b"\x1b" not in nocolor.stderr, repr(nocolor.stderr)))
        forced = subprocess.run([str(exe), "check", bad], capture_output=True,
                                env={k: v for k, v in dict(os.environ, CLICOLOR_FORCE="1").items()
                                     if k != "NO_COLOR"})
        checks.append(("CLICOLOR_FORCE", b"\x1b[1;31m" in forced.stderr, repr(forced.stderr)))
        code, out, err = tc.run_capture([exe, "check", "--color", "sometimes", probe])
        checks.append(("--color sometimes (refused)", code == 1 and "auto, always or never" in err,
                       out + err))
        # The completion scripts, from the help: each names every command,
        # and bash's, run, completes a command, an option and a file.
        for shell in ["bash", "zsh", "fish", "powershell"]:
            code, out, err = tc.run_capture([exe, "completion", shell])
            # fish names a long option without its dashes.
            names = ["-l debug", "-l check"] if shell == "fish" else ["--debug", "--check"]
            checks.append((f"completion {shell}", code == 0 and
                           all(v in out for v in ["build", "format", ".goose", *names]),
                           out[:400] + err))
            if shell in ("bash", "zsh") and shutil.which(shell) and os.name != "nt":
                script = gendir / f"completion.{shell}"
                tc.write_text(script, out)
                if shell == "bash":
                    tc.write_text(gendir / "complete_me.goose", "fn main() {}\n")
                    probe_sh = (f"source '{script}'; t() {{ COMP_WORDS=(\"$@\"); "
                                "COMP_CWORD=$(( ${#COMP_WORDS[@]} - 1 )); COMPREPLY=(); _goose; "
                                "echo \"${COMPREPLY[*]}\"; }; t goose bu; t goose build --dr; t goose complete_m")
                    r2 = subprocess.run(["bash", "-c", probe_sh], capture_output=True, text=True,
                                        cwd=gendir)
                    lines = r2.stdout.splitlines()
                    checks.append(("completion bash, run", lines == ["build", "--dry-run", "complete_me.goose"],
                                   r2.stdout + r2.stderr))
                else:
                    r2 = subprocess.run(["zsh", "-n", str(script)], capture_output=True, text=True)
                    checks.append(("completion zsh parses", r2.returncode == 0, r2.stderr))
        code, out, err = tc.run_capture([exe, "completion", "tcsh"])
        checks.append(("completion tcsh (refused)", code == 1 and "bash, zsh, fish or powershell" in err,
                       out + err))
        # The man page holds every command's help.
        code, man, err = tc.run_capture([exe, "help", "--man"])
        checks.append(("help --man", code == 0 and man.startswith(".TH GOOSE 1") and
                       all(f".SS {v}\n" in man for v in ["run", "build", "format", "completion"]),
                       man[:400] + err))
        if shutil.which("groff") and os.name != "nt":
            page = gendir / "goose.1"
            tc.write_text(page, man)
            r2 = subprocess.run(["groff", "-man", "-ww", "-z", str(page)], capture_output=True, text=True)
            checks.append(("help --man is a man page groff reads without warnings",
                           r2.returncode == 0 and not r2.stderr, r2.stderr))
        # Less than a page or two of data stack is no reservation to run on.
        code, out, err = tc.run_capture([exe, "check", "--stack-reserve", "5000", probe])
        checks.append(("check --stack-reserve 5000 (refused)",
                       code == 1 and "from 64 KB" in err, out + err))
        # --no-bce warns that the program's checkfree functions go unverified,
        # and not about the standard library's.
        nobce = gendir / "verbs_nobce.goose"
        tc.write_text(nobce, "import std;\nfn main() { print(min(1, 2)); }\n")
        code, out, err = tc.run_capture([exe, "check", "--no-bce", nobce])
        checks.append(("check --no-bce, std's checkfree", code == 0 and not out and not err, out + err))
        tc.write_text(nobce, "import std;\ncheckfree fn f(x: i64) -> i64 { min(x, 2) }\n"
                             "fn main() { print(f(1)); }\n")
        code, out, err = tc.run_capture([exe, "check", "--no-bce", nobce])
        checks.append(("check --no-bce, a checkfree fn", code == 0 and
                       "checkfree is not verified under --no-bce" in err, out + err))
        # The help: `goose --help` on the commands, `goose <command> --help`
        # and `goose help <topic>` on each, which between them name every
        # option the driver reads, but for the hidden shader ones.
        code, overview, err = tc.run_capture([exe, "--help"])
        checks.append(("--help", code == 0 and "build" in overview and
                       "--multi-test" not in overview, overview + err))
        pages = overview
        for cmd in ["run", "build", "check", "fetch", "format", "toolchain", "version", "lsp",
                    "completion"]:
            code, out, err = tc.run_capture([exe, cmd, "--help"])
            checks.append((f"{cmd} --help", code == 0 and
                           out.startswith(f"usage: goose {cmd}"), out + err))
            pages += out
        for topic in ["c", "internals"]:
            code, out, err = tc.run_capture([exe, "help", topic])
            checks.append((f"help {topic}", code == 0 and out.startswith("usage:"), out + err))
            pages += out
        hidden = {"--compile-shader", "--shader-source"}
        options = set(re.findall(r'arg == "(-[^"]+)"',
                                 (HERE.parent / "src" / "main.cpp").read_text(encoding="utf-8")))
        missing = sorted(o for o in options - hidden if not re.search(re.escape(o) + r"\b", pages))
        checks.append(("help on every option", len(options) > 20 and not missing,
                       f"in no help: {missing}"))
        code, out, err = tc.run_capture([exe, "help", "build"])
        checks.append(("help build", code == 0 and "--dry-run" in out, out + err))
        code, out, err = tc.run_capture([exe, "help", "nosuch"])
        checks.append(("help nosuch (refused)", code == 1 and "no help on nosuch" in err,
                       out + err))
        code, out, err = tc.run_capture([exe])
        checks.append(("(no file)", code == 1 and "usage:" in err and "--help" in err, out + err))
        code, out, err = tc.run_capture([exe, "build"])
        checks.append(("build (no file)", code == 1 and "usage: goose build" in err and
                       "goose build --help" in err, out + err))
        # The compiler's own toolchain discovery: where this runner found a C
        # compiler, the compiler must find one too, and say so as JSON.
        code, out, err = tc.run_capture([exe, "toolchain", "--json"])
        try:
            info = json.loads(out)
            good = (cc is None or info.get("cc") is not None) and \
                   code == (0 if info.get("cc") else 1)
        except ValueError:
            good = False
        checks.append(("toolchain --json", good, out + err))
        # A control character in what it reports is escaped, not lost.
        home = str(gendir / "home\twith a tab")
        tab = subprocess.run([str(exe), "toolchain", "--json"], capture_output=True, text=True,
                             errors="replace", env=dict(os.environ, GOOSE_HOME=home))
        try:
            good = json.loads(tab.stdout).get("home") == home.replace("\\", "/")
        except ValueError:
            good = False
        checks.append(("toolchain --json with a tab in GOOSE_HOME", good, tab.stdout + tab.stderr))
        # A directory on PATH that has a tool's name is not that tool.
        fakebin = gendir / "fakebin"
        (fakebin / "git").mkdir(parents=True, exist_ok=True)
        found = subprocess.run([str(exe), "toolchain", "--json"], capture_output=True, text=True,
                               errors="replace",
                               env=dict(os.environ, PATH=os.pathsep.join(
                                   [str(fakebin), os.environ.get("PATH", "")])))
        try:
            git = json.loads(found.stdout).get("git")
            good = not git or Path(git["path"]) != fakebin / "git"
        except ValueError:
            good = False
        checks.append(("toolchain --json with a directory named git on PATH", good,
                       found.stdout + found.stderr))
        # With no C compiler anywhere, every one looked for is named.
        nowhere = gendir / "nowhere"
        nowhere.mkdir(exist_ok=True)
        env = {k: v for k, v in os.environ.items()
               if k.upper() not in ("GOOSE_CC", "PATH", "PROGRAMFILES", "PROGRAMW6432",
                                     "PROGRAMFILES(X86)")}
        # Nothing on PATH, no Visual Studio where vswhere would be, and no
        # LLVM where its installer puts it. Windows gives a 64-bit process
        # ProgramFiles from ProgramW6432, so that one is hidden too.
        env.update({"PATH": str(nowhere), "GOOSE_HOME": str(nowhere / "home"),
                    "PROGRAMFILES": str(nowhere), "PROGRAMW6432": str(nowhere),
                    "PROGRAMFILES(X86)": str(nowhere)})
        nocc = subprocess.run([str(exe), "toolchain"], capture_output=True, text=True,
                              errors="replace", env=env)
        names = re.search(r"cannot find a C compiler \(looked for ([^)]*)\)", nocc.stdout)
        checks.append(("toolchain with no C compiler",
                       nocc.returncode == 1 and names is not None and
                       all(re.search(rf"\b{n}\b", names[1]) for n in ("clang", "gcc", "cc")),
                       nocc.stdout + nocc.stderr))
        # A C compiler that cannot be started is reported with the reason.
        notcc = gendir / ("not_a_compiler" + tc.EXE_SUFFIX)
        tc.write_text(notcc, "not a program\n")
        code, out, err = tc.run_capture([exe, "build", "--cc", str(notcc), "-o",
                                         str(gendir / ("never" + tc.EXE_SUFFIX)), probe])
        checks.append(("build --cc <not a program> (refused)",
                       code == 1 and "cannot start" in out + err and "No error" not in out + err,
                       out + err))
        if cc:
            # `goose build` against the toolchain the compiler finds itself:
            # the executable beside -o, running; a dry run writing none.
            built = gendir / ("verbs_built" + tc.EXE_SUFFIX)
            code, out, err = tc.run_capture([exe, "build", "-o", str(built), probe])
            good = code == 0 and built.exists()
            if good:
                code, out2, err2 = tc.run_capture([built])
                good = code == 0 and out2.strip() == "verbs"
                out, err = out + out2, err + err2
            checks.append(("build", good, out + err))

            shared_src = gendir / "verbs_shared.goose"
            tc.write_text(shared_src,
                          'export "goose_add" fn add(a: i32, b: i32) -> i32 { a + b }\n')
            shared_suffix = ".dll" if tc.IS_WINDOWS else ".dylib" if tc.IS_MACOS else ".so"
            shared_out = gendir / ("verbs_shared" + shared_suffix)
            code, out, err = tc.run_capture(
                [exe, "build", "--shared", "-o", str(shared_out), shared_src])
            good = code == 0 and shared_out.exists()
            detail = out + err
            if good:
                try:
                    lib = ctypes.CDLL(str(shared_out.resolve()))
                    lib.goose_init.argtypes = [ctypes.c_int,
                                               ctypes.POINTER(ctypes.c_char_p)]
                    lib.goose_init.restype = None
                    lib.goose_add.argtypes = [ctypes.c_int32, ctypes.c_int32]
                    lib.goose_add.restype = ctypes.c_int32
                    lib.goose_exit.argtypes = []
                    lib.goose_exit.restype = None
                    lib.goose_init(0, None)
                    good = lib.goose_add(20, 22) == 42
                    lib.goose_exit()
                except (AttributeError, OSError) as e:
                    good = False
                    detail += str(e)
            checks.append(("build --shared", good, detail))

            # A shared build can also emit the C host header. Exercise the
            # documented host surface and make sure the declarations are there.
            shared_header = gendir / "verbs_shared.h"
            shared_header_out = gendir / ("verbs_shared_header" + shared_suffix)
            code, out, err = tc.run_capture(
                [exe, "build", "--shared", "--header", str(shared_header),
                 "-o", str(shared_header_out), shared_src])
            good = code == 0 and shared_header_out.exists() and shared_header.exists()
            detail = out + err
            if good:
                header_text = shared_header.read_text(encoding="utf-8", errors="replace")
                good = all(name in header_text
                           for name in ("goose_init", "goose_exit", "goose_add"))
            checks.append(("build --shared --header", good, detail))

            # Without -o, the platform's normal shared-library spelling is used.
            default_src = gendir / "verbs_shared_default.goose"
            tc.write_text(default_src,
                          'export "goose_add" fn add(a: i32, b: i32) -> i32 { a + b }\n')
            default_out = gendir / (
                "verbs_shared_default.dll" if tc.IS_WINDOWS else
                "libverbs_shared_default.dylib" if tc.IS_MACOS else
                "libverbs_shared_default.so")
            if default_out.exists():
                default_out.unlink()
            code, out, err = tc.run_capture([exe, "build", "--shared", default_src])
            checks.append(("build --shared default output",
                           code == 0 and default_out.exists(), out + err))

            # Shared-library mode, like --header, requires something for the
            # host to call.
            no_export = gendir / "verbs_shared_no_export.goose"
            tc.write_text(no_export, "fn helper() -> i32 { 1 }\n")
            no_export_out = gendir / ("verbs_shared_no_export" + shared_suffix)
            code, out, err = tc.run_capture(
                [exe, "build", "--shared", "-o", str(no_export_out), no_export])
            checks.append(("build --shared without export (refused)",
                           code == 1 and
                           "--header and --shared require at least one export fn"
                           in out + err,
                           out + err))

            code, out, err = tc.run_capture([exe, "check", "--shared", probe])
            checks.append(("check --shared (refused)",
                           code == 1 and "--shared is an option of goose build" in err,
                           out + err))

            dry = gendir / ("verbs_dry" + tc.EXE_SUFFIX)
            code, out, err = tc.run_capture([exe, "build", "--dry-run", "-o", str(dry), probe])
            checks.append(("build --dry-run", code == 0 and not dry.exists() and
                           "verbs" in out and "goose_runtime" in out, out + err))
        for what, good, text in checks:
            if good:
                r.ok(f"goose {what}")
            else:
                r.fail(f"goose {what}", text)
    r.show_task(driver_verbs)

    def compiler_discovery():
        import unittest
        import toolchain_selection
        result = unittest.TestResult()
        unittest.defaultTestLoader.loadTestsFromModule(toolchain_selection).run(result)
        if result.testsRun and result.wasSuccessful():
            r.ok("compiler discovery: --exe as given, else build/'s Release, RelWithDebInfo, "
                 "single-configuration and Debug compilers in that order; a missing --exe, "
                 "or no compiler, refused")
        else:
            r.fail("compiler discovery", "".join(trace for _, trace in result.errors +
                                                 result.failures) or "no tests ran")
    r.show_task(compiler_discovery)

    def cli_paths():
        from cli_paths import check_cli_paths
        try:
            check_cli_paths(exe, cc, gendir)
            r.ok("command line paths: new -o directories, \".\" and \"..\" sources, rooted "
                 "--include, unresolved imports, a directory as a source or an embed_file, "
                 "the configured standard library, no runtime sources")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("command line paths", str(e))
    r.show_task(cli_paths)

    def emit_order():
        from emit_order import check_emit_order
        try:
            n = check_emit_order(HERE.parent / "src")
            r.ok(f"emit order: no two of the code generator's {n} emitting members in one "
                 "unsequenced expression, so the C it writes is the same whichever C++ "
                 "compiler built it")
        except RuntimeError as e:
            r.fail("emit order", str(e))
    r.show_task(emit_order)

    def deep_expressions():
        from deep_expressions import check_deep_expressions
        try:
            check_deep_expressions(exe, cc, gendir)
            r.ok("deep expressions: sums thousands of terms long, written as C a compiler "
                 "takes, run" + (" and built" if cc else "") + ", operands still in order")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("deep expressions", str(e))
    r.show_task(deep_expressions)

    def diagnostics_json():
        from diagnostics_json import check_diagnostics_json
        try:
            check_diagnostics_json(exe, gendir)
            r.ok("diagnostics as JSON: the text mode's text, positions and ranges, the "
                 "instantiation chain at its calls, warnings, several errors at once")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("diagnostics as JSON", str(e))
    r.show_task(diagnostics_json)

    def doc_comments():
        from doc_comments import check_doc_comments
        try:
            check_doc_comments(exe, gendir)
            r.ok("documentation comments: the comment lines above declarations, fields and "
                 "variants, and what ends a run of them")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("documentation comments", str(e))
    r.show_task(doc_comments)

    def format_layout():
        from format import check_format
        try:
            check_format(exe, gendir)
            r.ok("format: the layout of the golden cases, each a fixed point, and the command "
                 "line: in place, --check, the directory walk, errors and exit codes")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("format", str(e))
    r.show_task(format_layout)

    def format_sweep():
        from format import check_format_sweep
        try:
            summary = check_format_sweep(exe, [HERE.parent / "samples", HERE.parent / "stdlib",
                                               HERE.parent / "bench", HERE])
            r.ok(f"format --verify over samples, stdlib, bench and test: {summary}")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("format --verify", str(e))
    r.show_task(format_sweep)

    def lsp_protocol():
        from lsp_protocol import check_lsp_protocol
        try:
            check_lsp_protocol(exe, gendir)
            r.ok("language server: diagnostics, hover, definition, references, rename, symbols, "
                 "call hierarchy, semantic tokens, signature help, inlay hints, folding and selection ranges, "
                 "completion, code lenses, edits and cancellation, requests right behind a change")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("language server", str(e))
    r.show_task(lsp_protocol)

    r.section("native builds, packages and runtime I/O")

    def extern_types():
        from extern_types import check_extern_types
        try:
            check_extern_types(exe, cc, gendir, jit=jit, runtime=r.runtime, extra=extra)
            r.ok("extern types: unused and partially used C adapters")
        except RuntimeError as e:
            r.fail("extern types", str(e))
    if cc or jit:
        r.show_task(extern_types)

    def extern_dylib():
        from extern_dylib import check_extern_dylib
        try:
            check_extern_dylib(exe, cc, gendir, jit=jit, runtime=r.runtime, extra=extra)
            r.ok("extern dylib: a block's members bound from a shared library by name, "
                 "missing library and symbol, unused members, a package with both kinds")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("extern dylib", str(e))
    if cc:
        r.show_task(extern_dylib)

    def resource_paths():
        from resource_paths import check_resource_paths
        try:
            check_resource_paths(exe, cc, gendir, jit=jit, runtime=r.runtime, extra=extra)
            r.ok("resource paths: JIT/native roots, relocation and unchanged cwd")
        except RuntimeError as e:
            r.fail("resource paths", str(e))
    if cc or jit:
        r.show_task(resource_paths)

    def jit_runtime():
        from jit_runtime import check_jit_runtime
        try:
            check_jit_runtime(exe, gendir)
            r.ok("embedded JIT runtime: bundled files, exit/abort statuses and resource roots")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("embedded JIT runtime", str(e))
    if jit:
        r.show_task(jit_runtime)

    def git_packages():
        from packages_git import check_git_packages
        try:
            skipped = check_git_packages(exe, gendir, jit=jit)
            if skipped:
                r.say(f"skip packages from git ({skipped})")
            else:
                r.ok("packages from git: concurrent fetches, submodules, interrupted fetch, "
                     "tag, commit, update, differing ref, offline, cache path")
        except RuntimeError as e:
            r.fail("packages from git", str(e))
    r.show_task(git_packages)

    def runtime_cache():
        from runtime_cache import check_runtime_cache
        try:
            check_runtime_cache(exe, cc, gendir)
            r.ok("runtime cache: concurrent builds, failed compile, retry and reuse")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("runtime cache", str(e))
    if cc:
        r.show_task(runtime_cache)

    def native_cache():
        from native_cache import check_native_cache
        try:
            check_native_cache(exe, cc, gendir)
            r.ok("native part cache: concurrent builds of one package compile its C once")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("native part cache", str(e))
    if cc:
        r.show_task(native_cache)

    def runtime_io():
        from runtime_io import check_runtime_io
        try:
            check_runtime_io(exe, gendir, jit=jit)
            r.ok("runtime io: stdin's bytes as they came, read_line into a builder holding a "
                 "carriage return, a NUL byte and a 70,000-byte line, write_file_atomic "
                 "keeping a file's permissions")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("runtime io", str(e))
    if cc:
        r.show_task(runtime_io)

    def exit_race():
        from exit_race import check_exit_race
        try:
            check_exit_race(exe, gendir)
            r.ok("exit race: threads exiting at once end with their code")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("exit race", str(e))
    if cc:
        r.show_task(exit_race)

    def huge_pages():
        from huge_pages import check_huge_pages
        try:
            skipped = check_huge_pages(exe, gendir)
            if skipped:
                r.say(f"skip huge pages ({skipped})")
            else:
                r.ok("huge pages: data stack regions start without them")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("huge pages", str(e))
    if cc:
        r.show_task(huge_pages)

    def libm_calls():
        from libm_calls import check_libm_calls
        try:
            skipped = check_libm_calls(exe, [cc, clang], gendir)
            if skipped:
                r.say(f"skip libm calls ({skipped})")
            else:
                r.ok("libm calls: math's functions known to gcc and clang as libm's")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("libm calls", str(e))
    if cc or clang:
        r.show_task(libm_calls)

    def commit_limit():
        from commit_limit import check_commit_limit
        try:
            skipped = check_commit_limit(exe, gendir)
            if skipped:
                r.say(f"skip commit limit ({skipped})")
            else:
                r.ok("commit limit: a data stack the system will not commit is out of memory")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("commit limit", str(e))
    if cc:
        r.show_task(commit_limit)

    def native_toolchain():
        from native_toolchain import check_native_toolchain
        try:
            skipped = check_native_toolchain(exe, gendir, jit=jit)
            if skipped:
                r.say(f"skip native toolchain ({skipped})")
            else:
                r.ok("native toolchain: one C toolchain for a CMake package, the runtime "
                     "and the link")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("native toolchain", str(e))
    if cc:
        r.show_task(native_toolchain)

    def cmake_response_files():
        from native_toolchain import check_cmake_response_files
        try:
            skipped = check_cmake_response_files(exe, gendir)
            if skipped:
                r.say(f"skip CMake response files ({skipped})")
            else:
                r.ok("CMake response files: cc-style archive paths with and without spaces")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("CMake response files", str(e))
    if cc:
        r.show_task(cmake_response_files)

    def native_rebuild():
        from native_rebuild import check_native_rebuild
        try:
            skipped = check_native_rebuild(exe, gendir, jit=jit)
            if skipped:
                r.say(f"skip native rebuild ({skipped})")
            else:
                r.ok("native rebuild: edited C, new and excluded extern fns, CMake options, targets "
                     "and C++")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("native rebuild", str(e))
    if cc:
        r.show_task(native_rebuild)

    def native_builder():
        from native_builder import check_native_builder
        try:
            skipped = check_native_builder(exe, gendir, jit=jit)
            if skipped:
                r.say(f"skip native builder ({skipped})")
            else:
                r.ok("native builder: C appends to a builder through goose.h, a program's and "
                     "a CMake package's")
        except (RuntimeError, OSError, subprocess.TimeoutExpired) as e:
            r.fail("native builder", str(e))
    if cc:
        r.show_task(native_builder)

    show_goose_in_goose()

    # --- JIT: the same programs, compiled and run inside the compiler --------
    # No C file, no external toolchain: what this checks is that the generated
    # C is portable enough for a third, very different C implementation, and
    # that a program means the same when TinyCC builds it.
    r.section("JIT (TinyCC) runs")
    if not jit:
        r.show_later(r.say, "skip JIT run tests (sanitizer profile, --no-jit, or a compiler "
                            "built without the TinyCC backend)")
    else:
        for kind in ("jit", "jitdebug"):
            for f in tests:
                r.show(lambda f=f, kind=kind: getattr(fixtures[f].result(), kind))

        def jit_skips():
            skipped = [name for f in tests for name in fixtures[f].result().jitskips]
            if skipped:
                r.say(f"skip {len(skipped)} JIT test(s) the backend cannot run yet: "
                      + ", ".join(sorted(set(skipped))))
        r.show_later(jit_skips)

    parse_errors = sorted((HERE / "errors").glob("*.goose"))
    parse_runs = r.goose_each(["--parse"], parse_errors)

    def parse_error(f):
        code, out, err = r.screened(f, parse_runs[f]())
        if r.check_error(f, "expected-error", code, out, err):
            r.ok(f"error {f.name}")
    r.section("parse errors (errors/)")
    for f in parse_errors:
        r.show_later(parse_error, f)

    # Typecheck error tests: must parse, must fail the typechecker. One
    # compiler run tells the two apart by whether it reported the parse done.
    tc_errors = sorted((HERE / "errors_tc").glob("*.goose")) + native_errors
    tc_runs = r.goose_each(["--check"], tc_errors)

    def tc_error(f):
        code, out, err = r.screened(f, tc_runs[f]())
        if not re.search(r"^parsed ok:", out + err, re.M):
            r.fail(f"tc-error-parses {f.name}", out + err)
        elif r.check_error(f, "expected-tc-error", code, out, err):
            r.ok(f"tc-error {f.name}")
    r.section("typecheck errors (errors_tc/ and native modules' rejection tests)")
    for f in tc_errors:
        r.show_later(tc_error, f)

    # Recovery fixtures: several errors each, which the parser and the
    # checker go on past (docs/design/language_server.md §5 D), reported in
    # the order found, in text and as JSON. Each `// error:` marker is part
    # of the message of the error in its position, and there are no others.
    recovery = sorted((HERE / "errors_tc" / "recovery").glob("*.goose"))
    recovery_runs = r.goose_each(["--check"], recovery)

    def recovery_error(f):
        code, out, err = r.screened(f, recovery_runs[f]())
        if code != 1 or tc.sanitizer_failure(err):
            r.fail(f"recovery {f.name} (exit {code})", out + err)
            return
        markers = error_markers(f)
        heads = [m[1] for m in (re.match(r"^\S.*:\d+(?::\d+)?: error: (.*)$", line)
                                for line in err.splitlines()) if m]

        def in_order(got):
            return len(got) == len(markers) and all(m in g for m, g in zip(markers, got))
        if not in_order(heads):
            r.fail(f"recovery {f.name}: the errors in order",
                   "want:\n" + "\n".join(markers) + "\ngot:\n" + "\n".join(heads) + "\n" + err)
            return
        jcode, jout, jerr = r.goose("check", "--diagnostics", "json", f)
        try:
            diags = json.loads(jout)
        except ValueError:
            diags = []
        messages = [d["message"] for d in diags if d.get("severity") == "error"]
        if jcode != 1 or not in_order(messages) or any("line" not in d for d in diags):
            r.fail(f"recovery {f.name}: --diagnostics json", jout + jerr)
            return
        r.ok(f"recovery {f.name}")
    r.section("recovery (errors_tc/recovery/)")
    for f in recovery:
        r.show_later(recovery_error, f)

    r.section("long call chains and guard runs")
    for future in deep:
        r.show(future)

    r.section("language reference examples (docs/reference.md)")
    r.show(doc_examples_future)

    r.section("samples")
    r.show(samples_future)

    r.flush()
    if r.pool:
        r.pool.shutdown()
    print(f"({time.perf_counter() - started:.0f}s with {args.jobs} job(s))")
    return r.finish()


if __name__ == "__main__":
    sys.exit(main())
